-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: localhost    Database: new_ticket
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ticket_attachments`
--

DROP TABLE IF EXISTS `ticket_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_attachments` (
  `ticket` int(20) NOT NULL,
  `notice` int(20) NOT NULL,
  `file` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_attachments`
--

LOCK TABLES `ticket_attachments` WRITE;
/*!40000 ALTER TABLE `ticket_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_changelog`
--

DROP TABLE IF EXISTS `ticket_changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_changelog` (
  `ticket` int(10) NOT NULL,
  `option` varchar(255) NOT NULL,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `date` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_changelog`
--

LOCK TABLES `ticket_changelog` WRITE;
/*!40000 ALTER TABLE `ticket_changelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_form`
--

DROP TABLE IF EXISTS `ticket_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_form` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `element` varchar(255) NOT NULL,
  `option` varchar(255) NOT NULL,
  `rank` int(10) NOT NULL,
  `default` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_form`
--

LOCK TABLES `ticket_form` WRITE;
/*!40000 ALTER TABLE `ticket_form` DISABLE KEYS */;
INSERT INTO `ticket_form` (`id`, `element`, `option`, `rank`, `default`) VALUES (1,'group','Admin',0,NULL);
/*!40000 ALTER TABLE `ticket_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_notices`
--

DROP TABLE IF EXISTS `ticket_notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_notices` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `date` int(20) DEFAULT NULL,
  `ticket` int(10) NOT NULL,
  `notice` text NOT NULL,
  `private` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_notices`
--

LOCK TABLES `ticket_notices` WRITE;
/*!40000 ALTER TABLE `ticket_notices` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_tickets`
--

DROP TABLE IF EXISTS `ticket_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_tickets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `created` int(20) NOT NULL,
  `subject` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `comment` varchar(255) NOT NULL,
  `category` int(10) DEFAULT NULL,
  `priority` int(10) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `severity` int(10) DEFAULT NULL,
  `project` int(10) DEFAULT NULL,
  `platform` int(10) DEFAULT NULL,
  `reporter` varchar(255) DEFAULT NULL,
  `reporter_email` varchar(255) DEFAULT NULL,
  `reporter_salutation` varchar(3) DEFAULT NULL,
  `reporter_forename` varchar(255) DEFAULT NULL,
  `reporter_lastname` varchar(255) DEFAULT NULL,
  `reporter_firm` varchar(255) DEFAULT NULL,
  `reporter_office` varchar(255) DEFAULT NULL,
  `reporter_phone` varchar(255) DEFAULT NULL,
  `supporter` varchar(255) DEFAULT NULL,
  `group` varchar(255) DEFAULT NULL,
  `updated` int(20) NOT NULL,
  `updater` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_tickets`
--

LOCK TABLES `ticket_tickets` WRITE;
/*!40000 ALTER TABLE `ticket_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-12 13:48:17
