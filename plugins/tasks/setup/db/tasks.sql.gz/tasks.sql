-- MySQL dump 10.13  Distrib 8.0.31, for Linux (x86_64)
--
-- Host: localhost    Database: ticket
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tasks_attachments`
--

DROP TABLE IF EXISTS `tasks_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks_attachments` (
  `task` int NOT NULL,
  `notice` int DEFAULT NULL,
  `file` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks_attachments`
--

LOCK TABLES `tasks_attachments` WRITE;
/*!40000 ALTER TABLE `tasks_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks_changelog`
--

DROP TABLE IF EXISTS `tasks_changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks_changelog` (
  `row` int NOT NULL AUTO_INCREMENT,
  `task` int NOT NULL,
  `option` varchar(255) NOT NULL,
  `from` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `login` varchar(255) NOT NULL,
  `date` int NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks_changelog`
--

LOCK TABLES `tasks_changelog` WRITE;
/*!40000 ALTER TABLE `tasks_changelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks_changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks_form`
--

DROP TABLE IF EXISTS `tasks_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks_form` (
  `id` int NOT NULL AUTO_INCREMENT,
  `element` varchar(255) NOT NULL,
  `option` varchar(255) NOT NULL,
  `rank` int NOT NULL,
  `default` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks_form`
--

LOCK TABLES `tasks_form` WRITE;
/*!40000 ALTER TABLE `tasks_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks_notices`
--

DROP TABLE IF EXISTS `tasks_notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks_notices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `date` int DEFAULT NULL,
  `task` int NOT NULL,
  `notice` text NOT NULL,
  `private` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks_notices`
--

LOCK TABLES `tasks_notices` WRITE;
/*!40000 ALTER TABLE `tasks_notices` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks_notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks_tasks`
--

DROP TABLE IF EXISTS `tasks_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` int NOT NULL,
  `subject` varchar(140) NOT NULL,
  `description` text NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `flag_01` int DEFAULT NULL,
  `flag_02` int DEFAULT NULL,
  `flag_03` int DEFAULT NULL,
  `flag_04` int DEFAULT NULL,
  `flag_05` int DEFAULT NULL,
  `flag_06` int DEFAULT NULL,
  `flag_07` int DEFAULT NULL,
  `flag_08` int DEFAULT NULL,
  `flag_09` int DEFAULT NULL,
  `flag_10` int DEFAULT NULL,
  `reporter` varchar(255) DEFAULT NULL,
  `supporter` varchar(255) DEFAULT NULL,
  `group` varchar(255) DEFAULT NULL,
  `callback` varchar(100) DEFAULT NULL,
  `referer` varchar(100) DEFAULT NULL,
  `tag` varchar(100) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  `updated` int DEFAULT NULL,
  `updater` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks_tasks`
--

LOCK TABLES `tasks_tasks` WRITE;
/*!40000 ALTER TABLE `tasks_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 18:53:10
