-- MySQL dump 10.13  Distrib 5.5.61, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: bestand-master
-- ------------------------------------------------------
-- Server version	5.5.61-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bestand`
--

DROP TABLE IF EXISTS `bestand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(15) NOT NULL,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `tabelle` varchar(30) DEFAULT NULL,
  `merkmal_kurz` varchar(30) NOT NULL,
  `wert` varchar(1024) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand`
--

LOCK TABLES `bestand` WRITE;
/*!40000 ALTER TABLE `bestand` DISABLE KEYS */;
/*!40000 ALTER TABLE `bestand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_custom`
--

DROP TABLE IF EXISTS `bestand_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_custom` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `merkmal_kurz` varchar(50) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` tinyint(1) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  `bezeichner_kurz` varchar(1024) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Merkmale';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_custom`
--

LOCK TABLES `bestand_custom` WRITE;
/*!40000 ALTER TABLE `bestand_custom` DISABLE KEYS */;
/*!40000 ALTER TABLE `bestand_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_gebaeude`
--

DROP TABLE IF EXISTS `bestand_gebaeude`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_gebaeude` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `merkmal_kurz` varchar(50) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` tinyint(1) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  `bezeichner_kurz` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_gebaeude`
--

LOCK TABLES `bestand_gebaeude` WRITE;
/*!40000 ALTER TABLE `bestand_gebaeude` DISABLE KEYS */;
INSERT INTO `bestand_gebaeude` (`row`, `merkmal_kurz`, `merkmal_lang`, `datentyp`, `pflichtfeld`, `minimum`, `maximum`, `bezeichner_kurz`) VALUES (1,'RAUM','Raum','text',NULL,NULL,30,'*'),(2,'GEB','Gebäude','text',NULL,NULL,30,'*'),(3,'WE','Wirtschaftseinheit','text',NULL,NULL,30,NULL);
/*!40000 ALTER TABLE `bestand_gebaeude` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_index`
--

DROP TABLE IF EXISTS `bestand_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_index` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `tabelle_kurz` varchar(50) NOT NULL,
  `tabelle_lang` varchar(255) NOT NULL,
  `pos` int(5) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_index`
--

LOCK TABLES `bestand_index` WRITE;
/*!40000 ALTER TABLE `bestand_index` DISABLE KEYS */;
INSERT INTO `bestand_index` (`row`, `tabelle_kurz`, `tabelle_lang`, `pos`) VALUES (1,'merkmale','Merkmale',3),(6,'gebaeude','Gebäude',1),(7,'kopfdaten','Kopfdaten',2),(8,'custom','Custom',4),(9,'prozess','Prozess',5);
/*!40000 ALTER TABLE `bestand_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_kopfdaten`
--

DROP TABLE IF EXISTS `bestand_kopfdaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_kopfdaten` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `merkmal_kurz` varchar(50) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` int(2) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  `bezeichner_kurz` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_kopfdaten`
--

LOCK TABLES `bestand_kopfdaten` WRITE;
/*!40000 ALTER TABLE `bestand_kopfdaten` DISABLE KEYS */;
INSERT INTO `bestand_kopfdaten` (`row`, `merkmal_kurz`, `merkmal_lang`, `datentyp`, `pflichtfeld`, `minimum`, `maximum`, `bezeichner_kurz`) VALUES (2,'HERSTELLER','Hersteller','text',NULL,NULL,255,'*'),(3,'BAUJAHR','Baujahr','text',NULL,NULL,255,'*'),(4,'HERSTELLER_SERIAL_NR','Typ, Hersteller Serial Nr.','text',NULL,NULL,255,'*'),(5,'HERSTELLER_TEIL_NR','Hersteller Teile Nr.','text',NULL,NULL,255,'*'),(6,'TYP_BEZ','Typ/Bezeichnung','text',NULL,NULL,255,'*'),(12,'TECHN_PLZ','Technischer Platz','text',NULL,NULL,255,'*'),(14,'ANLAGENBESCHREIBUNG','Anlagenbeschreibung','text',NULL,NULL,255,'*'),(16,'BEMERKUNG','Bemerkung','textarea',NULL,NULL,512,'*');
/*!40000 ALTER TABLE `bestand_kopfdaten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_merkmale`
--

DROP TABLE IF EXISTS `bestand_merkmale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_merkmale` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `merkmal_kurz` varchar(50) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` tinyint(1) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  `bezeichner_kurz` varchar(1024) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=966 DEFAULT CHARSET=utf8 COMMENT='Merkmale';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_merkmale`
--

LOCK TABLES `bestand_merkmale` WRITE;
/*!40000 ALTER TABLE `bestand_merkmale` DISABLE KEYS */;
INSERT INTO `bestand_merkmale` (`row`, `merkmal_kurz`, `merkmal_lang`, `datentyp`, `pflichtfeld`, `minimum`, `maximum`, `bezeichner_kurz`) VALUES (483,'ABSCHALTBAR_PHOTO','Anlage abschaltbar','select',NULL,0,255,'PVA'),(484,'ABWASSER_FORTLEITUNG','Abwasserfortleitung','select',NULL,0,255,'KLK'),(485,'ALARMIERUNG_SAA','Alarmierung SAA','select',NULL,0,255,'BMA,BMAV'),(486,'ANBINDUNG_BOS','Anbindung','select',NULL,0,255,'BOS'),(487,'ANLAGENNUMMER_BHKW','Anlagennummer','text',NULL,0,255,'BHKW'),(488,'ANLAGENNUMMER_BRENNST','Anlagennummer','text',NULL,0,255,'BRSTZ'),(489,'ANLAGENNUMMER_NOTSTROM_NEA','Anlagennummer','text',NULL,0,255,'USVDA,USVDS'),(490,'ANLAGENNUMMER_PHOTO','Anlagennummer','text',NULL,0,255,'PVA'),(491,'ANMELDUNG_BHKW','Datum der Anmeldung bei der BNetzA','text',NULL,0,255,'BHKW'),(492,'ANMELDUNG_BRENNST','Datum der Anmeldung bei der BNetzA','text',NULL,0,255,'BRSTZ'),(493,'ANMELDUNG_NOTSTROM_NEA','Datum der Anmeldung bei der BNetzA','text',NULL,0,255,'USVDA,USVDS'),(494,'ANMELDUNG_PHOTO','Datum der Anmeldung bei der BNetzA','text',NULL,0,255,'PVA'),(495,'ANSCHLUSS_AN_WASSERVER','Anschluss an Wasserversorgungsnetz','select',NULL,0,255,'DEA,HMA,TWL,TWVA'),(496,'ANSCHLUSS_FERNWAERME','Anschluss Fernwärme','select',NULL,0,255,'WUEG,WUEGO'),(497,'ANSCHLUSS_WAERMEVERT','Anschluss Wärmeverteilung','select',NULL,0,255,'KWP,KP,WP'),(498,'ANSCHLUTZ_NETZ_NA','Anschluss an Wasserversorgungsnetz','select',NULL,0,255,'WDNF,WDNFDA,WDNFDM,WDNS,WDNSDA,WDNSDM'),(499,'ANSTEUERUNG_LUEFTUNGANL_CO','Ansteuerung Lüftungsanlage','select',NULL,0,255,'COWA'),(500,'ANTRIEB_FBA','Antrieb','select',NULL,0,255,'FBA'),(501,'ANTRIEB','Antriebsart','select',NULL,0,255,'LAH,LAS,PAH,PAS'),(502,'ANTRIEBART_GA','Antriebsart','select',NULL,0,255,'GAH,GAS'),(503,'ANTRIEBSART_BRANDSCH_ABLF_RWA','Antriebsart','select',NULL,0,255,'RWAG,RWAM,RWAN'),(504,'ANTRIEBSART','Antriebsart','select',NULL,0,255,'KWP,KP,WP'),(505,'ANWENDUNGSBEREICH_KKS','Anwendungsbereich','select',NULL,0,255,'KKS'),(506,'ANWENDUNGSBEREICH_KSA','Anwendungsbereich','select',NULL,0,255,'SKG'),(507,'ANWENDUNGSBEREICH_MSPLI','Anwendungsbereich','select',NULL,0,255,'MSPLA'),(508,'ANWENDUNGSBEREICH','Anwendungsbereich','select',NULL,0,255,'WEA'),(509,'ANWENDUNGSBEREICH1','Anwendungsbereich','select',NULL,0,255,'ESU'),(510,'ANWENDUNGSZWECK_KEZ','Anwendungszweck','select',NULL,0,255,'KEZ,RKA'),(511,'ANZ_1POL_STROMKR_NSHV','Anzahl 1-pol. Stromkreise','text',0,0,255,'GHV,NSHV'),(512,'ANZ_1POL_STROMKR_UV','Anzahl 1-pol. Stromkreise','text',0,0,255,'UVA,UVS,UVU'),(513,'ANZ_3POL_STROMKR_NSHV','Anzahl 3-pol. Stromkreise','text',0,0,255,'GHV,NSHV'),(514,'ANZ_3POL_STROMKR_UV','Anzahl 3-pol. Stromkreise','text',0,0,255,'UVA,UVS,UVU'),(515,'ANZ_ABSPERRARMATUREN_HV','Anzahl Absperrarmaturen','text',0,0,255,'HV'),(516,'ANZ_ANST_EINHE','Anzahl der unterschiedlichen ansteuerbaren Einheiten','text',0,0,255,'SSK,VDAK'),(517,'ANZ_AUSLOESE','Anzahl Auslösestationen','text',0,0,255,'MRA,RWAN,RWAG,RWAM'),(518,'ANZ_DATENPUNKTE_MSRHEIZ','Anzahl Datenpunkte','text',0,0,255,'MSR'),(519,'ANZ_FI_NSHV','Anzahl FI','text',0,0,255,'GHV,NSHV'),(520,'ANZ_FI_UV','Anzahl FI','text',0,0,255,'UVA,UVS,UVU'),(521,'ANZ_FLUE','Anzahl Flügel','select',NULL,0,255,'ATUERK,FTSA,FTK,RT,ST'),(522,'ANZ_FLUE1','Anzahl Flügel','select',NULL,0,255,'ITUER,SHT'),(523,'ANZ_FLUE2','Anzahl Flügel','select',NULL,0,255,'FTSI,ITUERK'),(524,'ANZ_FLUE3','Anzahl Flügel','select',NULL,0,255,'BSTOZ,BSTKU,BST'),(525,'ANZ_FLUE4','Anzahl Flügel','select',NULL,0,255,'BSTF,FSNZ'),(526,'ANZ_FLUE5','Anzahl Flügel','select',NULL,0,255,'BSTK'),(527,'ANZ_HUP_SIER_BLINK','Anzahl Hupen/Sirenen/Blinklichter','text',0,0,255,'BMA,BMAV'),(528,'ANZ_HY_NA','Anzahl Hydranten','text',0,0,255,'WDNF,WDNFDA,WDNFDM,WDNS,WDNSDA,WDNSDM'),(529,'ANZ_HY_NATR','Anzahl Hydranten','text',0,0,255,'WDNTF,WDNTFDA,WDNTFDM,WDNTS,WDNTSDA,WDNTSDM'),(530,'ANZ_HY_TR','Anzahl Hydranten','text',0,0,255,'WDTF,WDTS'),(531,'ANZ_MELDERTYP_AUTO_BRAND','Anzahl Meldertyp Automatisch','text',0,0,255,'BMA,BMAV'),(532,'ANZ_MELDERTYP_HAND_BRAND','Anzahl Meldertyp Hand','text',0,0,255,'BMA,BMAV'),(533,'ANZ_MELDERTYP_HAND_EINBRUCH_GME','Anzahl Meldertyp Hand','text',0,0,255,'EMA,UEMA'),(534,'ANZ_MELDERTYP_KONTAKT_EINBRUCH_GME','Anzahl Meldertyp Kontakt','text',0,0,255,'EMA,UEMA'),(535,'ANZ_MELDERTYP_RAS_AUFZUG','Anzahl Meldertyp RAS in Aufzugsschächten','text',0,0,255,'BMA,BMAV'),(536,'ANZ_MELDERTYP_RAS_BRAND','Anzahl Meldertyp RAS','text',0,0,255,'BMA,BMAV'),(537,'ANZ_MELDERTYP_SONST_EINBRUCH_GME','Anzahl Meldertyp, sonstiges','text',0,0,255,'EMA,UEMA'),(538,'ANZ_NEBENSTELLE_NUFI','Anzahl Nebenstellen','text',0,0,255,'TKA'),(539,'ANZ_RWA_OEFFNUNG','Anzahl RWA-Öffnungen','text',0,0,255,'RWAN,RWAG,RWAM'),(540,'ANZ_SPRINKLERKOEPFE','Anzahl Sprüh-/Sprinklerköpfe','text',0,0,255,'SPRN,SPRNT,SPRT'),(541,'ANZ_STEIGLTG_NA','Anzahl Steigleitungen','text',0,0,255,'WDNF,WDNFDA,WDNFDM,WDNS,WDNSDA,WDNSDM'),(542,'ANZ_STEIGLTG_NATR','Anzahl Steigleitungen','text',0,0,255,'WDNTF,WDNTFDA,WDNTFDM,WDNTS,WDNTSDA,WDNTSDM'),(543,'ANZ_STEIGLTG_TR','Anzahl Steigleitungen','text',0,0,255,'WDTF,WDTS'),(544,'ANZ_STUF_BLK','Anzahl Stufen','text',0,0,255,'BLK'),(545,'ANZ_TANKSTELLE','Anzahl','text',0,0,255,'KTB,KTD,KTDU,LSEF,TSA,ZSL'),(546,'ANZ_ZENTR_UNTER_GME','Anzahl (Unter-) Zentralen','text',0,0,255,'EMA,UEMA'),(547,'ANZ_ZENTR_UNTER','Anzahl (Unter-) Zentralen','text',0,0,255,'BMA,BMAV'),(548,'ANZAHL_ABL','Anzahl Ableitungen','text',0,0,255,'BLZA,BLZI,PTA,PTAS'),(549,'ANZAHL_ABSPERRAMATUREN_KV','Anzahl Absperrarmaturen','text',0,0,255,'KV'),(550,'ANZAHL_ALARMBENTILISATION_SPR','Anzahl Alarmventilstation','text',0,0,255,'SPRN,SPRNT,SPRT'),(551,'ANZAHL_ANTENNE_BOS','Anzahl Antennen','text',0,0,255,'BOS'),(552,'ANZAHL_BRFL','Anzahl','text',0,0,255,'FLA,FLB,FLC,FLD,FLF,FLS,FLW,FLWN,HFLA12,HFLA1,HFLA2,HFLA3,HFLA4,HFLA6,HFLA9,HFLB12,HFLB1,HFLB2,HFLB3,HFLB4,HFLB6,HFLB9,HFLC2,HFLC5,HFLD12,HFLD9,HFLF3,HFLF6,HFLS6,HFLS9,HFLW6,HFLW9,HFLWN6,HFLWN10'),(553,'ANZAHL_DACHEINLAESSE','Anzahl Dacheinlässe','text',0,0,255,'DCR'),(554,'ANZAHL_DATEN_LUFT_MSR','Anzahl der Datenpunkte','text',0,0,255,'MSR'),(555,'ANZAHL_DRUCKMIND','Anzahl Druckminderer','text',0,0,255,'DEA,HMA,TWL,TWVA'),(556,'ANZAHL_DRUCKREGELKLAP_DRA','Anzahl Druckregelklappen','text',0,0,255,'DBLS'),(557,'ANZAHL_DUESEN_GASLOE','Anzahl Löschdüsen','text',0,0,255,'COLA,ILA'),(558,'ANZAHL_EINSPEISUNG_TR','Anzahl Einspeisungen','text',0,0,255,'WDTF,WDTS'),(559,'ANZAHL_ENTNAHMESTELLE_GV','Anzahl der Entnahmestellen','text',0,0,255,'GVDT,GVZT,GVT,HRGW'),(560,'ANZAHL_ENTRAUCHUNGSKLAP_MRA','Anzahl Entrauchungsklappen','text',0,0,255,'MRA'),(561,'ANZAHL_ERHITZER_ZUAB','Anzahl Erhitzer','text',0,0,255,'RLTK,RLTU,RLT'),(562,'ANZAHL_FEUERWEHR_BEDIENFELD_BOS','Anzahl Feuerwehr-Bedienfeld','text',0,0,255,'BOS'),(563,'ANZAHL_FILTER_HV','Anzahl Filter/Schmutzfänger','text',0,0,255,'HV'),(564,'ANZAHL_FLASCHEN_GASLOE','Anzahl Flaschen','text',0,0,255,'COLA,ILA'),(565,'ANZAHL_HALTE','Anzahl Haltestellen','text',0,0,255,'LAH,LAS,PAH,PAS'),(566,'ANZAHL_HALTESTELLE_GA','Anzahl Haltestellen','text',0,0,255,'GAH,GAS'),(567,'ANZAHL_HEIZKR','Anzahl der Heizkreise','text',0,0,255,'HV'),(568,'ANZAHL_HEIZKREISE_KV','Anzahl Heizkreise','text',0,0,255,'KV'),(569,'ANZAHL_HUPEN_CO','Anzahl Hupen','text',0,0,255,'COWA'),(570,'ANZAHL_HUPEN_GMS','Anzahl Hupen','text',0,0,255,'GWA'),(571,'ANZAHL_KABINEN_PT','Anzahl Kabinen','text',0,0,255,'PT'),(572,'ANZAHL_KAMERAS_SUSI','Anzahl Kameras','text',0,0,255,'VUEW'),(573,'ANZAHL_KLAPPEN_ABL','Anzahl Rauch-, Brandschutzklappen','text',0,0,255,'ABL,RLT,RLTU,RLTK'),(574,'ANZAHL_KLAPPEN_ASA','Anzahl Rauch-, Brandschutzklappen','text',0,0,255,'ASA'),(575,'ANZAHL_KLAPPEN_DIG','Anzahl Rauch-, Brandschutzklappen','text',0,0,255,'LAB,LAZ'),(576,'ANZAHL_KLAPPEN_RUECK_HV','Anzahl Rückschlagklappen','text',0,0,255,'HV'),(577,'ANZAHL_KOMPRESSOR_SPR','Anzahl Kompressoren','text',0,0,255,'SPRN,SPRNT,SPRT'),(578,'ANZAHL_KUPPLUNG_TR','Anzahl Kupplungen','text',0,0,255,'WDTF,WDTS'),(579,'ANZAHL_MELDELINIE_GME','Anzahl Meldelinien','text',0,0,255,'EMA,UEMA'),(580,'ANZAHL_MELDELINIE','Anzahl Meldelinien','text',0,0,255,'BMA,BMAV'),(581,'ANZAHL_MELDETYP_BEWEGUNG_GME','Anzahl Meldertyp Bewegung','text',0,0,255,'EMA,UEMA'),(582,'ANZAHL_MESSFELDER_NSHV','Anzahl der Messfelder zur Hauptverteilung','text',0,0,255,'GHV,NSHV'),(583,'ANZAHL_MESSSTELLEN_CO','Anzahl Messstellen','text',0,0,255,'COWA'),(584,'Anzahl_MESSSTELLEN_GMS','Anzahl Messstellen','text',0,0,255,'GWA'),(585,'ANZAHL_OBERFLURHYDRANT','Anzahl Oberflurhydranten','text',0,0,255,'LWA,UEFH,UFH'),(586,'ANZAHL_PUMPE_HZV','Anzahl der Pumpen','text',0,0,255,'HV'),(587,'ANZAHL_PUMPEN_KV','Anzahl der Pumpen','text',0,0,255,'KV'),(588,'ANZAHL_PUMPEN','Anzahl Pumpen','text',0,0,255,'RGWA'),(589,'ANZAHL_PUMPEN_NA','Anzahl Pumpen','text',0,0,255,'WDNF,WDNFDA,WDNFDM,WDNS,WDNSDA,WDNSDM'),(590,'ANZAHL_PUMPEN1','Anzahl Pumpen','text',0,0,255,'GWB'),(591,'ANZAHL_ROHRTR','Anzahl Rohrtrenner','text',0,0,255,'DEA,HMA,TWL,TWVA'),(592,'ANZAHL_RUECKKLAPPEN_KV','Anzahl Rückschlagklappen','text',0,0,255,'KV'),(593,'ANZAHL_RUEFLUSSVER','Anzahl Rückflussverhinderer','text',0,0,255,'DEA,HMA,TWL,TWVA'),(594,'ANZAHL_RUHEPODESTE','Anzahl Ruhepodeste','text',0,0,255,'LEI'),(595,'ANZAHL_SCHACHTTUEREN_GA','Anzahl Schachttüren','text',0,0,255,'GAH,GAS'),(596,'ANZAHL_SCHMUTZFAENGER_KV','Anzahl Filter/Schmutzfänger','text',0,0,255,'KV'),(597,'ANZAHL_SPUELEIN','Anzahl Spüleinrichtungen','text',0,0,255,'DEA,HMA,TWL,TWVA'),(598,'ANZAHL_STELLVENTILE_KV','Anzahl der Stell-/Regelventile','text',0,0,255,'KV'),(599,'ANZAHL_TUER','Anzahl Türen am Korb','text',0,0,255,'LAH,LAS,PAH,PAS'),(600,'ANZAHL_TUEREN_KORB_GA','Anzahl Türen am Korb','text',0,0,255,'GAH,GAS'),(601,'ANZAHL_UMLUFT','Anzahl','text',0,0,255,'RLTU'),(602,'ANZAHL_UMSTEIGBUEH','Anzahl Umsteigebühnen','text',0,0,255,'LEI'),(603,'ANZAHL_UNTERFLURHYDRANT','Anzahl Unterflurhydranten','text',0,0,255,'LWA,UEFH,UFH'),(604,'ANZAHL_UNTERZENTRALE_SUSI','Anzahl (Unter-) Zentralen','text',0,0,255,'VUEW'),(605,'ANZAHL_VENTILATOREN_MRA','Anzahl Ventilatoren','text',0,0,255,'MRA'),(606,'ANZAHL_VENTILE_HV','Anzahl Stell-/Regelventile','text',0,0,255,'HV'),(607,'ANZAHL_WAERMEMENGENZAEHLER_KV','Anzahl der Wärmemengenzähler','text',0,0,255,'KV'),(608,'ANZAHL_WARNTRANSPARENTE_CO','Anzahl Warntransparente','text',0,0,255,'COWA'),(609,'ANZAHL_WARNTRANSPARENTE_GMS','Anzahl Warntransparente','text',0,0,255,'GWA'),(610,'ANZAHL_WASSERZ','Anzahl Wasserzähler','text',0,0,255,'DEA,HMA,TWL,TWVA'),(611,'ANZAHL_ZAEHLER_HV','Anzahl Wärmemengenzähler','text',0,0,255,'HV'),(612,'ART_ABWASSER','Abwasserart','select',NULL,0,255,'AWH,FKH,GWH'),(613,'ART_ANLAGE_FBA','Art der Anlage','select',NULL,0,255,'FBA'),(614,'ART_AUSLOESUNG_DRA','Art der Auslösung','select',NULL,0,255,'DBLS'),(615,'ART_BEFESTIGUNG','Art der Befestigung','select',NULL,0,255,'APA,API,SSS'),(616,'ART_BEHEIZ','Art der Beheizung','select',NULL,0,255,'DWT,SWT,ZSP'),(617,'ART_BETAETIG','Art der Betätigung','select',NULL,0,255,'ATUERK,FTSA,FTK,RT,ST'),(618,'ART_BETAETIG1','Art der Betätigung','select',NULL,0,255,'FTSI,ITUERK'),(619,'ART_BETAETIG2','Art der Betätigung','select',NULL,0,255,'BSTK'),(620,'ART_BRENNSTOFF','Brennstoff','select',NULL,0,255,'AOT,FLTB,HOL'),(621,'ART_DER_ANLAGE_SPRECH','Art der Anlage','select',NULL,0,255,'BWN,GSA'),(622,'ART_DER_ERWAERM','Art der Erwärmung','select',NULL,0,255,'DLE,UTG'),(623,'ART_DER_SCHLIESSUNG','Art der Schließung','select',NULL,0,255,'ITUER,SHT'),(624,'ART_DER_SCHLIESSUNG1','Art der Schließung','select',NULL,0,255,'BSTOZ,BSTKU,BST'),(625,'ART_DER_SCHLIESSUNG2','Art der Schließung','select',NULL,0,255,'BSTF,FSNZ'),(626,'ART_DER_ZELLE','Art der Zelle','select',NULL,0,255,'BRSTZ'),(627,'ART_DES_DACHES','Art des Daches','select',NULL,0,255,'DCR'),(628,'ART_DES_WAERMEVERTEILER','Art des Wärmeverteilers','select',NULL,0,255,'HV'),(629,'ART_ERSATZSTROM_SIBE','Art der Ersatz-Stromversorgung','select',NULL,0,255,'SIE,SIEZ,NBD,NBS,FPDU,FPSU'),(630,'ART_LOESCHANLAGE','Art der Löschanlage','select',NULL,0,255,'SPRN,SPRNT,SPRT'),(631,'ART_MEDIZINVERSORGUNG_GV','Art der Anlage','select',NULL,0,255,'GVDT,GVZT,GVT,HRGW'),(632,'ART_MESSSYSTEM_CO','Art des Messsystems','select',NULL,0,255,'COWA'),(633,'ART_NACHSTRÖMUNG_ZULUFT_MRA_','Art der Nachströmung/Zuluft','text',0,0,255,'MRA'),(634,'ART_STEUERUNG','Art der Steuerung','text',0,0,255,'BHKW'),(635,'ART_TUE_TO','Art der/des Tür/Tores','select',NULL,0,255,'ATUERK,FTSA,FTK,RT,ST'),(636,'ART_TUE_TOR','Art der/des Tür/Tores','select',NULL,0,255,'ITUER,SHT'),(637,'ART_TUE_TOR1','Art der/des Tür/Tores','select',NULL,0,255,'FTSI,ITUERK'),(638,'ART_TUE_TOR2','Art der/des Tür/Tores','select',NULL,0,255,'BSTOZ,BSTKU,BST'),(639,'ART_TUE_TOR3','Art der/des Tür/Tores','select',NULL,0,255,'BSTF,FSNZ'),(640,'ART_TUE_TOR4','Art der/des Tür/Tores','select',NULL,0,255,'BSTK'),(641,'ART_WAERMEVERTEILER_KV','Art des Wärmeverteilers','select',NULL,0,255,'KV'),(642,'AUFFANG_ANZ_ERD','Anzahl der Auffangvorichtungen','text',0,0,255,'BLZA,BLZI,PTA,PTAS'),(643,'AUFSCHALT_GLT','Aufschaltung Ü-GLT','select',NULL,0,255,'MSR'),(644,'AUFSCHALT_LUFT_GLT','Aufschaltung auf die Ü-GLT','select',NULL,0,255,'MSR'),(645,'AUFSCHALTUNG_FEUERWEHR','Aufschaltung Feuerwehr','select',NULL,0,255,'BMA,BMAV'),(646,'AUFSCHALTUNG_BMA','Aufschaltung BMA','select',NULL,0,255,'COLA,ILA'),(647,'AUFSCHALTUNG_GME','Aufschaltung Polizei','select',NULL,0,255,'EMA,UEMA'),(648,'AUFSCHALTUNG_SPR_BMA','Aufschaltung BMA','select',NULL,0,255,'SPRN,SPRNT,SPRT'),(649,'AUFSTELLART_PHOTO','Aufstellart','select',NULL,0,255,'PVA'),(650,'AUFSTELLART_SOLAR','Aufstellart','select',NULL,0,255,'THS'),(651,'AUSCHALTUNG_BMA_DRA','Aufschaltung BMA','select',NULL,0,255,'DBLS'),(652,'AUSCHALTUNG_BMA_MRA','Aufschaltung BMA','select',NULL,0,255,'RWAG,RWAM,RWAN'),(653,'AUSCHALTUNG_BMA','Aufschaltung BMA','select',NULL,0,255,'BSTF,FSNZ'),(654,'AUSLOESUNG_DURCH_MELDER','Auslösung durch Rauchmelder','select',NULL,0,255,'BSTF,FSNZ'),(655,'AUTO_NACHEINSPEISUNG_HV','automatische Nachspeiseeinrichtung','select',NULL,0,255,'HV'),(656,'AUTO_NACHEINSPEISUNG_KV','automatische Nachspeiseeinrichtung','select',NULL,0,255,'KV'),(657,'BATT_ANZ_SIBE','Anzahl Batterien','text',0,0,255,'SIE,SIEZ,FPDU,FPSU,NBD,NBS'),(658,'BATT_ANZ_USV','Anzahl Batterien','text',0,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(659,'BATTERIEBAUJ_USV','Batteriebaujahr','text',0,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(660,'BATTERIEKAPA_SIBE','Zentralbatteriekapazität in AH','text',0,0,255,'SIE,SIEZ,FPDU,FPSU,NBD,NBS'),(661,'BATTERIEKAPA_USV','Batteriekapazität in Ah','text',0,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(662,'BATTTYP_USV','Batterietyp','text',0,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(663,'BAUART_BRFL','Bauart der Feuerlöscher','select',NULL,0,255,'FLA,FLB,FLC,FLD,FLF,FLS,FLW,FLWN,HFLA12,HFLA1,HFLA2,HFLA3,HFLA4,HFLA6,HFLA9,HFLB12,HFLB1,HFLB2,HFLB3,HFLB4,HFLB6,HFLB9,HFLC2,HFLC5,HFLD12,HFLD9,HFLF3,HFLF6,HFLS6,HFLS9,HFLW6,HFLW9,HFLWN6,HFLWN9'),(664,'BAUART_DAMPFKESSEL','Bauart Dampfkessel','select',NULL,0,255,'HKDH'),(665,'BAUART_TRAFO','Transformatoren','select',NULL,0,255,'TFO,TFOF'),(666,'BAUART_UMLUFT','Bauart Umluft','select',NULL,0,255,'RLTU'),(667,'BAUART_VERDICHTERS','Bauart des Verdichters','select',NULL,0,255,'KEZ,RKA'),(668,'BEDIENUNG_SONNE','Art der Bedienung','select',NULL,0,255,'SSK,VDAK'),(669,'BEFESTIGUNG_EINSEHB','Befestigung einsehbar','select',NULL,0,255,'APA,API,SSS'),(670,'BEFESTIGUNG_EINSEHBAR','Befestigung einsehbar','select',NULL,0,255,'LEI'),(671,'BEFEUCHTUNGART_KKS','Befeuchtungsart','select',NULL,0,255,'KKS'),(672,'BEFEUCHTUNGSLEISTUNG_KKS','Befeuchtungsleistung in kg/h','text',0,0,255,'KKS'),(673,'BEFEUCHTUNGSLEISTUNG_ZUAB','Befeuchtungsleistung in kg/h','text',0,0,255,'RLTK,RLTU,RLT'),(674,'BEH_IN_M3','Behälter in m³','text',0,0,255,'AWH,FKH,GWH'),(675,'BEHAELTERGR','Vorlagebehälter in m³','text',0,0,255,'SPRN,SPRNT,SPRT'),(676,'BEHIN_IN_M3','Behälterinhalt in m³','text',0,0,255,'ALSG'),(677,'BESONDERHEIT','Besonderheit','select',NULL,0,255,'DCR'),(678,'BETREIBER_BHKW','Betreiber der Anlage','select',NULL,0,255,'BHKW'),(679,'BETREIBER_BRENNST','Betreiber der Anlage','select',NULL,0,255,'BRSTZ'),(680,'BETREIBER_NOTSTROM_NEA','Betreiber der Anlage','select',NULL,0,255,'USVDA,USVDS'),(681,'BETREIBER_PHOTO','Betreiber der Anlage','select',NULL,0,255,'PVA'),(682,'BETRIEBSART_BOS','Betriebsart','select',NULL,0,255,'BOS'),(683,'BETRIEBSDRUCK','max. Druck in bar','text',0,0,255,'DWT,SWT,ZSP'),(684,'BETRIEBSGESCHW','Geschwindigkeit in m/s','text',0,0,255,'LAH,LAS,PAH,PAS'),(685,'BETRIEBSWEISE','Betriebsweise','select',NULL,0,255,'KWP,KP,WP'),(686,'BETRIEBSWEISE_SIBE','Betriebsweise','select',NULL,0,255,'SIE,SIEZ,NBD,NBS,FPDU,FPSU'),(687,'BLITZSTROMABL_NSHV','Blitzstromableiter','select',NULL,0,255,'GHV,NSHV'),(688,'BRANDFALLMATIX_VOR','Brandfallmatrix vorhanden','select',NULL,0,255,'BMA,BMAV'),(689,'BREI','Breite in m','text',0,0,255,'TVH'),(690,'BRENNER_HERSTELLER','Brenner Hersteller','Text',0,0,255,'HKF,HKGG,HKG,HKD,HKH,HKO,HKS'),(691,'BRENNER_HERSTELLER2','Brenner Hersteller','text',0,0,255,'HKDH'),(692,'BRENNERTYP1','Brennertyp','text',0,0,255,'HKF,HKGG,HKG,HKD,HKH,HKO,HKS'),(693,'BRENNERTYP2','Brennertyp','text',0,0,255,'HKDH'),(694,'BRENNSTOFF_BHKW','Brennstoff','select',NULL,0,255,'BHKW'),(695,'BRUNNENDURCHM','Brunnendurchmesser in mm','text',0,0,255,'BRU'),(696,'BRUNNENNUTZUNG','Brunnennutzung','select',NULL,0,255,'BRU'),(697,'BRUNNENTIEFE','Brunnentiefe in m','text',0,0,255,'BRU'),(698,'CO2_EQUIVALENT_KKS','CO2-Äquivalent','text',NULL,0,255,'KKS'),(699,'CO2_EQUIVALENT_KSA','CO2-Äquivalent','text',0,0,255,'SKG'),(700,'CO2_EQUIVALENT','CO2-Äquivalent','text',0,0,255,'KEZ,RKA'),(701,'CO2_LOESCHANLAGE_GASLOE','CO2-Äquivalent des fluorierten Löschmittels','text',NULL,0,255,'COLA,ILA'),(702,'DAMPFLEISTUNG','Dampfleistung (kg/h)','text',0,0,255,'DAEZ'),(703,'DATENFERNUEBERTRAGUNG_MSA','Datenfernübertragung','select',NULL,0,255,'MSAG,MSA'),(704,'DETEKTIERTE_GASE_GMS','detektierte Gase','text',0,0,255,'GWA'),(705,'DOSIERMITTEL','Dosiermittel','text',0,0,255,'GWB'),(706,'DRUCK_IN_B','Druck in bar','text',0,0,255,'DBPF'),(707,'EEG_FÖRDERUNG_PHOTO','EEG Förderung','text',NULL,0,255,'PVA'),(708,'EEG_SCHLUESSEL_BRENNST','EEG Schlüssel','text',0,0,255,'BRSTZ'),(709,'EEG_SCHLUESSEL','EEG Schlüssel','text',0,0,255,'BHKW'),(710,'EEG_SCHLUESSEL_PHOTO','EEG Schlüssel','text',0,0,255,'PVA'),(711,'EIGEN_NOTSTROM_SPR','eigener Notstromdiesel','select',NULL,0,255,'SPRN,SPRNT,SPRT'),(712,'EIGENSTROMVERBRAUCH_BHKW','Eigenstromverbrauch / Einspeisung','select',NULL,0,255,'BHKW'),(713,'EIGENSTROMVERBRAUCH_BRENNST','Eigenstromverbrauch / Einspeisung','select',NULL,0,255,'BRSTZ'),(714,'EIGENSTROMVERBRAUCH_PHOTO','Eigenstromverbrauch / Einspeisung','select',NULL,0,255,'PVA'),(715,'EIGENTUEMER_BHKW','Eigentümer der Anlage','select',NULL,0,255,'BHKW'),(716,'EIGENTUEMER_BRENNST','Eigentümer der Anlage','select',NULL,0,255,'BRSTZ'),(717,'EIGENTUEMER_NOTSTROM_NEA','Eigentümer der Anlage','select',NULL,0,255,'USVDA,USVDS'),(718,'EIGENTUEMER_PHOTO','Eigentümer der Anlage','select',NULL,0,255,'PVA'),(719,'EIGENTUEMER_WAERMEP','Eigentümer der Anlage','select',NULL,0,255,'KWP,KP,WP'),(720,'EINGESETZTER_AUFBEREITUNGSSTOFF','eingesetzter Wasseraufbereitungsstoff','text',0,0,255,'DOA, DOAH'),(721,'EINGESETZTER_AUFBEREITUNGSSTOFF1','eingesetzter Wasseraufbereitungsstoff','text',0,0,255,'ESA'),(722,'EL_LEISTUNG','Leistung elektrisch in kW','text',0,0,255,'BHKW'),(723,'ELEKTRISCHE_SPANNUNG_BRENNST','Elektrische Spannung in V','text',0,0,255,'BRSTZ'),(724,'ELEKTRISCHELEISTW','Elektrische Leistung in W','text',0,0,255,'KWP,KP,WP'),(725,'ELT_SPANNUNG_BHKW','Elektrische Spannung','text',0,0,255,'BHKW'),(726,'ERSATZSTROMQUELLE_BOS','Ersatzstromquelle','text',0,0,255,'BOS'),(727,'ERSATZSTROMQUELLE_CO','Ersatzstromquelle','text',0,0,255,'COWA'),(728,'ERSATZSTROMQUELLE_GME','Ersatzstromquelle','text',0,0,255,'EMA,UEMA'),(729,'ERSATZSTROMQUELLE_GMS','Ersatzstromquelle','text',0,0,255,'GWA'),(730,'ERSATZSTROMQUELLE_SUSI','Ersatzstromquelle','text',0,0,255,'VUEW'),(731,'EX_BEREICH_GMS','EX-Bereich','select',NULL,0,255,'GWA'),(732,'EX_BEREICH_USV','EX-Bereich','select',NULL,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(733,'EXPLOSIONSSCHUTZ_DIG','Explosionsschutz','select',NULL,0,255,'LAB,LAZ'),(734,'FAHRST_LAENGE','Länge in m','text',0,0,255,'FST,FRT'),(735,'FELDER_ANZ_MSA','Anzahl Felder','text',0,0,255,'MSAG,MSA'),(736,'FESTSTELLVORRICHTUNG','Feststellvorrichtung','select',NULL,0,255,'BSTF,FSNZ'),(737,'FEUERWEHRAUFZUG','Feuerwehraufzug','select',NULL,0,255,'LAH,LAS,PAH,PAS'),(738,'FILTER_LUFT_ANZA','Filteranzahl','text',0,0,255,'ABL,RLT,RLTU,RLTK'),(739,'FILTER_LUFT_GROESSE','Filtergröße','text',0,0,255,'ABL,RLT,RLTU,RLTK'),(740,'FILTER_LUFT_KLAS','Filterklasse','text',0,0,255,'ABL,RLT,RLTU,RLTK'),(741,'FILTERANZAHL_DIG','Filteranzahl','text',0,0,255,'LAB,LAZ'),(742,'FILTERANZAHL_KKS','Filteranzahl','text',0,0,255,'KKS'),(743,'FILTERANZAHL_TLS','Filteranzahl','text',0,0,255,'TLSLA'),(744,'FILTERART_DIG','Filterart','select',NULL,0,255,'LAB,LAZ'),(745,'FILTERART_FA','Art des Filters','select',NULL,0,255,'DEA,HMA,RSFA,RSFM,FS,TWL,TWVA'),(746,'FILTERART_KKS','Filterart','select',NULL,0,255,'KKS'),(747,'FILTERART_TLS','Filterart','select',NULL,0,255,'TLSLA'),(748,'FILTERART1','Filterart','select',NULL,0,255,'GWB'),(749,'FILTERGROESSE_DIG','Filtergröße','select',NULL,0,255,'LAB,LAZ'),(750,'FILTERGROESSE_KKS','Filtergröße','select',NULL,0,255,'KKS'),(751,'FILTERGROESSE_TLS','Filtergröße','select',NULL,0,255,'TLSLA'),(752,'FILTERKLASSE_DIG','Filterklasse','select',NULL,0,255,'LAB,LAZ'),(753,'FILTERKLASSE_KKS','Filterklasse','select',NULL,0,255,'KKS'),(754,'FILTERKLASSE_TLS','Filterklasse','select',NULL,0,255,'TLSLA'),(755,'FLAECHE_IN_QM','Fläche in m²','text',0,0,255,'DCR,LD,PVA'),(756,'FLASCHENINHALT_GASLOESCH','Flascheninhalt in kg','text',0,0,255,'COLA,ILA'),(757,'FLUCHTUER_STEUERUNG','Fluchttürsteuerung','select',NULL,0,255,'ATUERK,FTSA,FTK,RT,ST'),(758,'FLUCHTUER_STEUERUNG1','Fluchttürsteuerung','select',NULL,0,255,'ITUER,SHT'),(759,'FLUCHTUER_STEUERUNG2','Fluchttürsteuerung','select',NULL,0,255,'FTSI,ITUERK'),(760,'FLUCHTUER_STEUERUNG3','Fluchttürsteuerung','select',NULL,0,255,'BSTOZ,BSTKU,BST'),(761,'FLUCHTUER_STEUERUNG4','Fluchttürsteuerung','select',NULL,0,255,'BSTF,FSNZ'),(762,'FLUCHTUER_STEUERUNG5','Fluchttürsteuerung','select',NULL,0,255,'BSTK'),(763,'FOERDERHOEHE','Förderhöhe in m','text',0,0,255,'LAH,LAS,PAH,PAS,FBA,GAH,GAS,ALK,BRK,PK,SLK,SAK,PT,HB,TL,HT,HAB'),(764,'FOERDERMENGE','Fördermenge in m³/h','text',0,0,255,'BRU'),(765,'FOERDERMITTEL_PHOTO','Errichtung mit Fördermitteln z.B. REN-Programm','text',0,0,255,'PVA'),(766,'FREITEXT1','Freitext','text',0,0,255,'HKF,HKGG,HKG,HKD,HKH,HKO,HKS,BHKW,BRSTOZ,ELZ,FLM,TABW,GTH,GVDT,GVZT,GVT,SKG,MSPLA,THS,KTB,KTD,KTDU,LSEF,TSA,ZSL,RLTU,KWP,KP,WP,SPRN,SPRNT,SPRT,FLA,FLB,FLC,FLD,FLF,FLS,FLW,FLWN,HFLA12,HFLA1,HFLA2,HFLA3,HFLA4,HFLA6,HFLA9,HFLB12,HFLB1,HFLB2,HFLB3,HFLB4,HFLB6,HFLB9,HFLC2,HFLC5,HFLD12,HFLD9,HFLF3,HFLF6,HFLS6,HFLS9,HFLW6,HFLW9,HFLWN6,HFLWN9,GMZ,LD,HRGW'),(767,'FREQUENZ_UMFORMER','Frequenzumformer','select',NULL,0,255,'DEA,HMA,TWL,TWVA'),(768,'FREQUENZUMFORMER_NA','Frequenzumformer','select',NULL,0,255,'WDNF,WDNFDA,WDNFDM,WDNS,WDNSDA,WDNSDM'),(769,'GASFUELLUNG','Gasfüllung','select',NULL,0,255,'DEA,HMA,TWL,TWVA'),(771,'GESCHWINDIGKEIT_GA','Geschwindigkeit in m/s','text',0,0,255,'GAH,GAS'),(772,'GESCHWINDIGKEIT_PT','Geschwindigkeit in m/s','text',0,0,255,'PT'),(773,'HEIZLEISTUNG_KKS','Heizleistung in kW','text',0,0,255,'KKS'),(774,'HEIZLEISTUNG_TLS','Heizleistung in kW','text',0,0,255,'TLSLA'),(775,'HEIZLEISTUNG_ZUAB','Heizleistung in kW','text',0,0,255,'RLTK,RLT'),(776,'HEIZMEDIUM','Heizmedium','select',NULL,0,255,'HKF,HKGG,HKG,HKD,HKH,HKO,HKS'),(777,'HEIZMEDIUM1','Heizmedium','select',NULL,0,255,'HKDH'),(778,'HOECHST_KONZ_NACH_AUFBE','Höchstkonzentration nach Aufbereitung in mg/L','text',0,0,255,'DOA, DOAH'),(779,'HOEHE','Höhe in m','text',0,0,255,'FAM,RL,RT,ST,TVH'),(780,'INBETRIEBNAHME_BHKW','Datum der Inbetriebnahme','text',0,0,255,'BHKW'),(781,'INBETRIEBNAHME_BRENNST','Datum der Inbetriebnahme','text',0,0,255,'BRSTZ'),(782,'INBETRIEBNAHME_NOTSTROM_NEA','Datum der Inbetriebnahme','text',0,0,255,'USVDA,USVDS'),(783,'INBETRIEBNAHME_PHOTO','Datum der Inbetriebnahme','text',0,0,255,'PVA'),(784,'INBETRIEBNAHME_WAERMEP','Datum der Inbetriebnahme','text',0,0,255,'KWP,KP,WP'),(785,'INHALT_AUFFANGBEH','Inhalt Auffangbehälter in m³','text',0,0,255,'RGWA'),(786,'INHALT','Gesamtinhalt in m3','text',0,0,255,'AOT,FLTB,HOL'),(787,'INHALTL','Volumen in l','text',0,0,255,'DWT,SWT,ZSP'),(788,'INTEGRIERTER_DRUCKMIN','integrierter Druckminderer','select',NULL,0,255,'DEA,HMA,RSFA,RSFM,FS,TWL,TWVA'),(789,'ISOLIERUNG_MSA','Isolierung','select',NULL,0,255,'MSAG,MSA'),(790,'KAELTEMITTEL_KEZ','Kältemittel','select',NULL,0,255,'KEZ,RKA'),(791,'KAELTEMITTEL_KKS','Kältemittel','select',NULL,0,255,'KKS'),(792,'KAELTEMITTEL_KSA','Kältemittel','select',NULL,0,255,'SKG'),(795,'KAELTEMITTEL_MSPLI','Kältemittel','select',NULL,0,255,'MSPLA'),(796,'KAELTEMITTEL_WAERMEPUMPE','Kältemittel','select',NULL,0,255,'KWP,KP,WP'),(797,'KATEGORIE_DES_DRUCKBEHAEL','Kategorie des Druckbehälters bzw. Prüfgruppe','select',NULL,0,255,'DEA,HMA,TWL,TWVA'),(798,'KATEGORIE_DRUCKBE_WASS','Kategorie des Druckbehälters bzw. Prüfgruppe','select',NULL,0,255,'SPRN,SPRNT,SPRT'),(799,'KLASSIFIZIERUNG','Klassifizierung','select',NULL,0,255,'BSTOZ,BSTKU,BST'),(800,'KLASSIFIZIERUNG1','Klassifizierung','select',NULL,0,255,'BSTF,FSNZ'),(801,'KLASSIFIZIERUNG2','Klassifizierung','select',NULL,0,255,'BSTK'),(802,'KOLLEKTORART','Art des Kollektors','select',NULL,0,255,'THS'),(803,'KOLLEKTORFLAECHE','Kollektorfläche in m²','text',0,0,255,'THS'),(804,'KONDENSATPUMPE_KSA','Kondensatpumpe','select',NULL,0,255,'SKG'),(805,'KONDENSATPUMPE_MSPLA','Kondensatpumpe','select',NULL,0,255,'MSPLA'),(806,'KONDENSATPUMPE_MSPLI','Kondensatpumpe','select',NULL,0,255,'MSPLA'),(807,'KONTI_MESS_SPEICH','kontinuierliche Messung und Speicherung vorhanden?','select',NULL,0,255,'DOA'),(808,'KONTI_MESS_SPEICH1','kontinuierliche Messung und Speicherung vorhanden?','select',NULL,0,255,'WEA'),(809,'KONTI_MESS_SPEICH2','kontinuierliche Messung und Speicherung vorhanden?','select',NULL,0,255,'ESA'),(810,'KUEHLLEIS_KSA','Kühlleistung in kW','text',0,0,255,'SKG'),(811,'KUEHLLEISTUNG_KEZ','Kühlleistung in kW','text',0,0,255,'KEZ,RKA'),(812,'KUEHLLEISTUNG_KKS','Kühlleistung in kW','text',0,0,255,'KKS'),(813,'KUEHLLEISTUNG_MSPLA','Kühlleistung in kW','text',0,0,255,'MSPLA'),(814,'KUEHLLEISTUNG_MSPLI','Kühlleistung in kW','text',0,0,255,'MSPLA'),(815,'KUEHLLEISTUNG_ZUAB','Kühlleistung in kW','text',0,0,255,'RLTK,RLT'),(816,'KUEHLMEDIUM_KEZ','Kühlmedium','select',NULL,0,255,'KEZ,RKA'),(817,'KUEHLUNG_ENTFEUCHTUNG_KKS','Kühlung/Entfeuchtung','select',NULL,0,255,'KKS'),(818,'KWKG_FOERDERUNG_BRENNST','KWKG-Förderung','select',NULL,0,255,'BRSTZ'),(819,'KWKG_FOERDERUNG','KWKG-Förderung','select',NULL,0,255,'BHKW'),(820,'LAENGE','Länge','text',0,0,255,'LEI'),(821,'LAENGE_ROHRNETZ','Länge Rohrnetz','text',0,0,255,'FGUB,FGVB'),(822,'LAGERSTANDORT','Lagerstandort','select',NULL,0,255,'AOT,FLTB,HOL'),(823,'LASTTRENNSCH_ANZ_MSA','Anzahl Lasttrennschalter','text',0,0,255,'MSAG,MSA'),(824,'LAUTSPR_ANZ','Anzahl Lautsprecher','text',0,0,255,'SAA'),(825,'LECKAGE_ERKENNUNG','Leckage-Erkennsystem','select',NULL,0,255,'KEZ,RKA'),(826,'LECKAGEERKENNUNGSSYST_GASLOE','Leckage-Erkennsystem','select',NULL,0,255,'COLA,ILA'),(827,'LECKAGEUEBERWACHUNG','Leckageüberwachung','select',NULL,0,255,'AOT,FLTB,HOL'),(828,'LEISTUNG_BLK','Blindleistung in kVAr','text',0,0,255,'BLK'),(829,'LEISTUNG_ELEKT_BRENNST','Leistung elektrisch in kW','text',0,0,255,'BRSTZ'),(830,'LEISTUNG_IN_KW','Leistung in kW','text',0,0,255,'GTH'),(831,'LEISTUNG_THERM_BRENNST','Leistung thermisch in kW','text',0,0,255,'BRSTZ'),(832,'LEISTUNG_WAERMETAUSCHER_KW','Leistung Wärmetauscher in kw','text',0,0,255,'WUEG,WUEGO'),(833,'LEISTUNGKW','Leistung in kW','text',0,0,255,'DWT,SWT,ZSP'),(834,'LEISTUNGSSCH_ANZ_MSA','Anzahl Leistungsschalter','text',0,0,255,'MSAG,MSA'),(835,'LEUCHT_ANZ_SIBE','Anzahl Leuchten','text',0,0,255,'SIE,SIEZ,FPDU,FPSU,NBD,NBS'),(836,'LINIEN_ANZ','Anzahl Linien','text',0,0,255,'SAA'),(837,'LIPUNK','Lichtpunkthöhe','text',0,0,255,'ABM, AUBL'),(838,'LOESCHMITTEL_BRFL','Art des Feuerlöschermittels','select',NULL,0,255,''),(839,'LUFTSROEUEBERWACHUNG_DIG','Luftstromüberwachung','select',NULL,0,255,'LAB,LAZ'),(840,'MATERIAL_BEH','Behältermaterial','select',NULL,0,255,'AOT,FLTB,HOL'),(841,'MAX_DRUCK_DRUCKBE','max. Druck in bar','text',0,0,255,'SPRN,SPRNT,SPRT'),(842,'MAX_DRUCK','max. Druck in bar','text',0,0,255,'DEA,HMA,TWL,TWVA,DLVD,DLVV,DLVZ'),(843,'MAX_DURCHMESSER','max. Durchmesser','text',0,0,255,'FGUB,FGVB'),(844,'MAXIMUM_DRUCK','max. Druck in bar','text',0,0,255,'WUEG,WUEGO'),(845,'MESSEINRICHTUNG_ENERGIE','Messeinrichtung für aufgewendete Energie','select',NULL,0,255,'KWP,KP,WP'),(846,'MESSEINRICHTUNG_PHOTO','Mess-/Zähleinrichtung','select',NULL,0,255,'PVA'),(847,'MISCHLUFTKAMMERN','Mischluftkammern','select',NULL,0,255,'RLTK'),(848,'NACHBEHANDLUNGSGERAET_ZUAB','Anzahl Nachbehandlungsgeräte','text',0,0,255,'RLTK,RLT'),(849,'NENNLEISTUNG_IN_KW','Nennleistung in kW','text',0,0,255,'HKF,HKGG,HKG,HKD,HKH,HKO,HKS'),(850,'NENNLEISTUNG_IN_KW1','Nennleistung in kW','text',0,0,255,'HKDH'),(851,'NENNLEISTUNG_PHOTO','Nennleistung in kWp','text',0,0,255,'PVA'),(852,'NENNLEISTUNG_SCHWUNG','kVA Nennleistung','text',0,0,255,'SRSPE'),(853,'NENNLEISTUNG_SPR','Nennleistung Notstromdiesel in kVA','text',0,0,255,'SPRN,SPRNT,SPRT'),(854,'NENNLEISTUNG_TRAFO','Leistung in kVA','text',0,0,255,'TFO,TFOF'),(855,'NENNLEISTUNG_USV','Nennleistung kVA','text',0,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(856,'NENNLEISTUNGKVA_NEA','kVA Nennleistung','text',0,0,255,'USVDA,USVDS'),(857,'NENNSPANNUNG_TRAFO','Nennspannung Primär in kv','text',0,0,255,'TFO,TFOF'),(858,'NENNSPANNUNG_TRAFO','Nennspannung Sekundär in kv','text',0,0,255,'TFO,TFOF'),(859,'NENNSPANNUNG_USV','Nennspannung in V','text',0,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(860,'NENNWEITE1','Nennweite (DN)','text',0,0,255,'DEA,HMA,RSFA,RSFM,FS,TWL,TWVA'),(861,'NEUTRALISATIONS_MITTEL','Neutralisationsmittel','select',NULL,0,255,'NAH'),(862,'NORMGRÖSSE','Normgröße in m³','text',0,0,255,'FA,FAWSG,KA,LFA,LFAWSG,SSA,SA,SAWSG'),(863,'NOTLEUCHTE_MSA','Notleuchte','select',NULL,0,255,'MSAG,MSA'),(864,'NOTLEUCHTE_NSHV','Notleuchte','select',NULL,0,255,'GHV,NSHV'),(865,'NOTRUF_AUFZUG','Notruf','select',NULL,0,255,'LAH,LAS,PAH,PAS'),(866,'NUTZUNGSART_GEBAEUDE','Nutzungsart des Gebäudes','select',NULL,0,255,'DWT,SWT,ZSP'),(867,'OELAUFFANGSYSTEM_TRAFO','Ölauffangsystem','select',NULL,0,255,'TFO,TFOF'),(868,'OELFUERENDE_UNTERIRDISCH_TEILE','ölführende unterirdisch verbaute Teile','select',NULL,0,255,'LAH,LAS,PAH,PAS'),(869,'OPFERANODE','Opferanode','select',NULL,0,255,'DWT,SWT,ZSP'),(870,'ORT_BEFESTIGUNG','Ort der Befestigung','select',NULL,0,255,'APA,API,SSS'),(871,'PROBELAUF_NEA','Probelauf','select',NULL,0,255,'USVDA,USVDS'),(872,'PUMPENLEISTUNG_NA','Pumpenleistung in kW','text',0,0,255,'WDNF,WDNFDA,WDNFDM,WDNS,WDNSDA,WDNSDM'),(873,'PUMPENLEISTUNG_SPR','Pumpenleistung in m3/h und bar','text',0,0,255,'SPRN,SPRNT,SPRT'),(874,'PUMPENTYP','Pumpentyp','select',NULL,0,255,'BRU'),(875,'PUMPLSTG_1','Pumpenleistung 1 in KW','text',0,0,255,'AWH,FKH,GWH'),(876,'PUMPLSTG_2','Pumpenleistung 2 in KW','text',0,0,255,'AWH,FKH,GWH'),(877,'PUMPLSTG','Pumpenleistung in KW','text',0,0,255,'RGWA'),(878,'PUMPLSTG1','Pumpenleistung in KW','text',0,0,255,'BRU'),(879,'PUMPLSTG2','Pumpenleistung in kW','text',0,0,255,'GWB'),(880,'REGEL_ANZ_MAX','Anzahl der Regelkreise','text',0,0,255,'MUE'),(881,'REGENRINNEN','Regenrinnen, Länge in m','text',0,0,255,'DCR'),(882,'RUECKENSCHUTZ','Rückenschutz','select',NULL,0,255,'LEI'),(883,'RUECKFUERUNG_BRUNNENWASSER','Rückführung Brunnenwasser','select',NULL,0,255,'BRU'),(884,'RUECKLAUFTTEMP_BEGRENZ','Rücklauftemperaturbegrenzung','select',NULL,0,255,'WUEG,WUEGO'),(885,'SCHAUMZUMISCHUNG_SPR','Schaumzumischung','select',NULL,0,255,'SPRN,SPRNT,SPRT'),(886,'SCHLITZKABEL_BOS','Schlitzkabel','select',NULL,0,255,'BOS'),(887,'SICHERHEITSABSCHALT_PHOTO','Sicherheitsabschaltung','select',NULL,0,255,'PVA'),(888,'SICHERHEITSSTROMVERS_NEA','Sicherheitsstromversorgung','select',NULL,0,255,'USVDA,USVDS'),(889,'SICHERHEITSSTROMVERS_SCHWUNG','Sicherheitsstromversorgung','select',NULL,0,255,'SRSPE'),(890,'SICHERHEITSTROMVERS_USV','Sicherheitsstromversorgung','select',NULL,0,255,'USVSA,USVSAZ,USVSB,USVSN,USVSR,USVSS,USVSI'),(891,'SICHTECH_FUN','Sicherheitstechnische Funktion','select',NULL,0,255,'VDAK'),(892,'SPEICHERLADESYSTEM','TWW Speicherladesystem','select',NULL,0,255,'DWT,SWT,ZSP'),(893,'SPRECHST_ANZ','Anzahl Sprechstellen','text',0,0,255,'SAA'),(894,'SPRECHST_ANZ','Anzahl der Ruf-, Sprech- und Signalstellen','text',0,0,255,'BWN,GSA'),(895,'STANDORT_AUSSENEINHEIT','Standort der Außeneinheit','text',0,0,255,'SKG'),(896,'STANDORT','Standort','select',NULL,0,255,'FA,FAWSG,KA,LFA,LFAWSG,SSA,SA,SAWSG'),(897,'STANDORT1','Standort','select',NULL,0,255,'GWB'),(898,'STEIGSCHUTZEINRICHTUNG','Steigschutzeinrichtung','select',NULL,0,255,'LEI'),(899,'STROMSTEUER_PHOTO','Stromsteuerentlastung','select',NULL,0,255,'PVA'),(900,'STROMSTEUERENTLASTUNG_BRENNST','Stromsteuerentlastung','select',NULL,0,255,'BRSTZ'),(901,'STROMSTEUERENTLASTUNG','Stromsteuerentlastung','select',NULL,0,255,'BHKW'),(902,'SV_NETZ_NSHV','SV-Netz','select',NULL,0,255,'GHV,NSHV'),(903,'SV_UMSCHALTEINRICHTUNG_NEA','SV-Umschalteinrichtung','select',NULL,0,255,'USVDA,USVDS'),(904,'SYSTEMTEMP_PRIMAER','Systemtemperatur Primär in Grad C','text',0,0,255,'WUEG,WUEGO'),(905,'SYSTEMTEMP_SEKUNDAER','Systemtemperatur Sekundär in Grad C','text',0,0,255,'WUEG,WUEGO'),(906,'TANKINHALT_NEA','Tankinhalt in l','text',0,0,255,'USVDA,USVDS'),(907,'TANKINHALT_NOTSTROMDIESEL_SPR','Tankinhalt Notstromdiesel in l','text',0,0,255,'SPRN,SPRNT,SPRT'),(908,'TEMP_IN_GR','Temperatur in Grad Celsius','text',0,0,255,'DBPF'),(909,'THERM_LEISTKW','Leistung thermisch in kW','text',0,0,255,'BHKW'),(910,'TRAGFAEHIGKE','Tragfähigkeit in kg','text',0,0,255,'APA,API,SSS,HAB,FBA,GAH,GAS,HB,HT,ALK,BRK,PK,SLK,SAK,PT,LAH,LAS,PAH,PAS,TL'),(911,'TRENN_ANZ','Anzahl Trennstellen','text',0,0,255,'BLZA,BLZI,PTA,PTAS'),(912,'TUER_WAECHTER','Türwächter','select',NULL,0,255,'ATUERK,FTSA,FTK,RT,ST'),(913,'UEBERSPANNUNGSCHUTZ_NSHV','Überspannungsschutz','select',NULL,0,255,'GHV,NSHV'),(914,'UEBERSPANNUNGSCHUTZ_UV','Überspannungsschutz','select',NULL,0,255,'UVA,UVS,UVU'),(915,'UMWELTZEICHEN_WAERMEP','Umweltzeichen / Prüfzeichen (Euroblume, Blauer Engel, EHPA)','text',0,0,255,'KWP,KP,WP'),(916,'UNTERGRUNDMATERIAL','Untergrundmaterial','select',NULL,0,255,'LEI'),(917,'UNTERGRUNDMATERIAL1','Untergrundmaterial','select',NULL,0,255,'APA,API,SSS'),(918,'VENTILATOREN_TYP_ABL','Ventilatoren/Typ','select',NULL,0,255,'ABL,ALFTR,RLT,RLTU,RLTK'),(919,'VENTILATOREN_TYP_DIG','Ventilatoren/Typ','select',NULL,0,255,'LAB,LAZ'),(920,'VERBRENNUNGSLUFT','Verbrennungsluft','select',NULL,0,255,'GTH'),(921,'VERDROSSELT_BLK','Verdrosselt','select',NULL,0,255,'BLK'),(922,'VERSORGUNGSNETZ_UV','Versorgungsnetz','select',NULL,0,255,'UVA,UVS,UVU'),(923,'VERWENDUNGSZWECK_ASA','Verwendungszweck','select',NULL,0,255,'ASA'),(924,'VERWENDUNGSZWECK_WASSER','Verwendungszweck Wasser','select',NULL,0,255,'RGWA'),(925,'VOLLGEKAPSELT_MSA','Vollgekapselt','select',NULL,0,255,'MSAG,MSA'),(926,'VOLUMEN_DRUCKBE','Volumen in m³','text',0,0,255,'SPRN,SPRNT,SPRT'),(927,'VOLUMEN_IN_LITER','Volumen in l','text',0,0,255,'DEA,HMA,TWL,TWVA,DBPF'),(928,'VOLUMEN_IN_LITER1','Volumen in l','text',0,0,255,'NAH'),(929,'VOLUMEN_WAERMETAUSCHER_L','Volumen Wärmetauscher in l','text',0,0,255,'WUEG,WUEGO'),(930,'VOLUMENSTROM_ABL','Volumenstrom in m³/h','text',0,0,255,'ABL,ALFTR,RLT,RLTU,RLTK'),(931,'VOLUMENSTROM_ASA','Volumenstrom in m³/h','text',0,0,255,'ASA'),(932,'VOLUMENSTROM_DIG','Volumenstrom in m³/h','text',0,0,255,'LAB,LAZ'),(933,'VOLUMENSTROM_DRA','Volumenstrom in m³/h','text',0,0,255,'DBLS'),(934,'VOLUMENSTROM_KKS','Volumenstrom in m³/h','text',0,0,255,'KKS'),(935,'VOLUMENSTROM_KSA','Volumenstrom in m3/h','text',0,0,255,'SKG'),(936,'VOLUMENSTROM_MRA','Volumenstrom in m³/h','text',0,0,255,'MRA'),(937,'VOLUMENSTROM_MSPLA','Volumenstrom in m³/h','text',0,0,255,'MSPLA'),(938,'VOLUMENSTROM_MSPLI','Volumenstrom in m³/h','text',0,0,255,'MSPLA'),(939,'VOLUMENSTROM_TLS','Volumenstrom in m³/h','text',0,0,255,'TLSLA'),(940,'WAERMELEISTKW','Wärmeleistung in kw','text',0,0,255,'KWP,KP,WP'),(941,'WAERMEMENGENZAELER_ABGEER_WP','Wärmemengenzähler für abgegebene Energie an WP','select',NULL,0,255,'KWP,KP,WP'),(942,'WAERMEPUMPENFUNKTION_KSA','Wärmepumpenfunktion','select',NULL,0,255,'SKG'),(943,'WAERMEQUELLE','Wärmequelle','select',NULL,0,255,'KWP,KP,WP'),(944,'WAERMETAUSCHER','Wärmetauscher','text',0,0,255,'WUEG,WUEGO'),(945,'WANDSICHERUNG','Wandsicherung','select',NULL,0,255,'AOT,FLTB,HOL'),(946,'WART_NACH_BETRIEBSST_BHKW','Wartung nach Betriebsstunden','text',0,0,255,'BHKW'),(947,'WASSERART','Wasserart','select',NULL,0,255,'RGWA'),(948,'WASSERAUFBEREITUNG','Wasseraufbereitung','select',NULL,0,255,'GWB'),(949,'WECHSELR_ANZ_PHOTO','Anzahl Wechselrichter','text',0,0,255,'PVA'),(950,'WERKSTOFF','Werkstoff, Behälter','select',NULL,0,255,'FA,FAWSG,KA,LFA,LFAWSG,SSA,SA,SAWSG'),(951,'ZAEHLEREINRICHTUNG_BREENNST','Zählereinrichtung','select',NULL,0,255,'BRSTZ'),(952,'ZAEHLEREINRICHTUNG','Zählereinrichtung','select',NULL,0,255,'BHKW'),(953,'ZENTRALBATTERIEBJ_SIBE','Zentralbatteriebaujahr','text',0,0,255,'SIE,SIEZ,FPDU,FPSU,NBD,NBS'),(954,'ZENTRALBATTERIETYP_SIBE','Zentralbatterietyp','text',0,0,255,'SIE,SIEZ,FPDU,FPSU,NBD,NBS'),(955,'ZENTRALE_ANSTEUERUNG','Zentrale Ansteuerung','select',NULL,0,255,'SSK,VDAK'),(956,'ZULAE_ZUGAB_DES_AUFBE_STOFFES','Zulässige Zugabe des Aufbereitungsstoffes in mg/L','text',0,0,255,'DOA, DOAH'),(957,'ZULAE_ZUGAB_DES_AUFBE_STOFFES1','Zulässige Zugabe des Aufbereitungsstoffes in mg/L','text',0,0,255,'WEA'),(958,'ZULAE_ZUGAB_DES_AUFBE_STOFFES2','Zulässige Zugabe des Aufbereitungsstoffes in mg/L','text',0,0,255,'ESA'),(959,'ZYLINDERZAHL_BHKW','Zylinderanzahl','text',0,0,255,'BHKW'),(960,'PROZESSIST','Prozessgruppe','select',NULL,NULL,NULL,'IGD'),(961,'BESCH','Beschreibung','textarea',NULL,NULL,NULL,'IGD'),(962,'EL','elektr. Leistung des Kompressors in kW','TEXT',0,0,30,'DLVD,DLVV,DLVZ'),(963,'ART_KOMP','Art des Kompressors','select',0,0,30,'DLVD,DLVV,DLVZ'),(964,'KAN_RAUCH','Kanalrauchmelder','select',NULL,NULL,255,'RLT,RLTU,RLTK,ABL'),(965,'TUER_NR','Tür/Tor Nr.','text',NULL,NULL,NULL,'');
/*!40000 ALTER TABLE `bestand_merkmale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_option2attrib`
--

DROP TABLE IF EXISTS `bestand_option2attrib`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_option2attrib` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(50) NOT NULL,
  `attrib` varchar(50) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=466 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_option2attrib`
--

LOCK TABLES `bestand_option2attrib` WRITE;
/*!40000 ALTER TABLE `bestand_option2attrib` DISABLE KEYS */;
INSERT INTO `bestand_option2attrib` (`row`, `option`, `attrib`) VALUES (227,'JA_NEIN','ABSCHALTBAR_PHOTO'),(228,'ABWASSER_FORTLEITUNG','ABWASSER_FORTLEITUNG'),(229,'JA_NEIN','ALARMIERUNG_SAA'),(230,'ANBINDUNG_BOS','ANBINDUNG_BOS'),(231,'ART_BEHEIZ','ANSCHLUSS_FERNWAERME'),(232,'ANSCHLUSS_WASSER_NETZ','ANSCHLUSS_AN_WASSERVER'),(233,'JA_NEIN','ANSCHLUSS_SV_NETZ_MRA'),(234,'ANSCHLUSS','ANSCHLUSS_WAERMEVERT'),(235,'ANSCHLUSS_WASSER_NETZ','ANSCHLUTZ_NETZ_NA'),(236,'JA_NEIN','ANSTEUERUNG_LUEFTUNGANL_CO'),(237,'ANTRIEB','ANTRIEBART_GA'),(238,'ANTRIEBSART','ANTRIEBSART_BRANDSCH_ABLF_RWA'),(239,'ANTRIEBSART','ANTRIEBSART'),(240,'ANTRIEB_FBA','ANTRIEB_FBA'),(241,'ANTRIEB','ANTRIEB'),(242,'ANWENDUNGSBEREICH','ANWENDUNGSBEREICH1'),(243,'ANWENDUNGSBEREICH','ANWENDUNGSBEREICH_KKS'),(244,'ANWENDUNGSBEREICH','ANWENDUNGSBEREICH_KSA'),(245,'ANWENDUNGSBEREICH','ANWENDUNGSBEREICH_MSPLI'),(246,'ANWENDUNGSBEREICH','ANWENDUNGSBEREICH'),(247,'ANWENDUNGSZWECK','ANWENDUNGSZWECK_KEZ'),(248,'ANZ_FLUE','ANZ_FLUE1'),(249,'ANZ_FLUE','ANZ_FLUE2'),(250,'ANZ_FLUE','ANZ_FLUE3'),(251,'ANZ_FLUE','ANZ_FLUE4'),(252,'ANZ_FLUE','ANZ_FLUE5'),(253,'ANZ_FLUE','ANZ_FLUE'),(254,'ART_ABWASSER','ART_ABWASSER'),(255,'ART_FBA','ART_ANLAGE_FBA'),(256,'ART_AUSLOESUNG_DRA','ART_AUSLOESUNG_DRA'),(257,'ART_BEFESTIGUNG','ART_BEFESTIGUNG'),(258,'ART_BEHEIZ','ART_BEHEIZ'),(259,'ART_BETAETIG','ART_BETAETIG1'),(260,'ART_BETAETIG','ART_BETAETIG2'),(261,'ART_BETAETIG','ART_BETAETIG'),(262,'ART_BRENNSTOFF','ART_BRENNSTOFF'),(263,'ART_SPRECHANL','ART_DER_ANLAGE_SPRECH'),(264,'ART_ERWAERM','ART_DER_ERWAERM'),(265,'ART_SCHLIESSUNG','ART_DER_SCHLIESSUNG1'),(266,'ART_SCHLIESSUNG','ART_DER_SCHLIESSUNG2'),(267,'ART_SCHLIESSUNG','ART_DER_SCHLIESSUNG'),(268,'ART_ZELLE','ART_DER_ZELLE'),(269,'ART_DACH','ART_DES_DACHES'),(270,'ART_WAERMEVERTEILER','ART_DES_WAERMEVERTEILER'),(271,'ART_ERSATZSTROM_SIBE','ART_ERSATZSTROM_SIBE'),(272,'ART_LOESCHANLAGE','ART_LOESCHANLAGE'),(273,'ART_MEDIZINVERSORGUNG','ART_MEDIZINVERSORGUNG_GV'),(274,'ART_MESSSYSTEM','ART_MESSSYSTEM_CO'),(275,'ART_TUER_TOR','ART_TUE_TOR1'),(276,'ART_TUER_TOR','ART_TUE_TOR2'),(277,'ART_TUER_TOR','ART_TUE_TOR3'),(278,'ART_TUER_TOR','ART_TUE_TOR4'),(279,'ART_TUER_TOR','ART_TUE_TOR'),(280,'ART_TUER_TOR','ART_TUE_TO'),(281,'ART_WAERMEVERTEILER','ART_WAERMEVERTEILER_KV'),(282,'JA_NEIN','AUFSCHALTUNG_FEUERWEHR'),(283,'JA_NEIN','AUFSCHALTUNG_GASLOE_BMA'),(284,'JA_NEIN','AUFSCHALTUNG_GME'),(285,'JA_NEIN','AUFSCHALTUNG_SPR_BMA'),(286,'JA_NEIN','AUFSCHALT_GLT'),(287,'JA_NEIN','AUFSCHALT_LUFT_GLT'),(288,'AUFSTELLART','AUFSTELLART_PHOTO'),(289,'AUFSTELLART','AUFSTELLART_SOLAR'),(290,'JA_NEIN','AUSCHALTUNG_BMA_DRA'),(291,'JA_NEIN','AUSCHALTUNG_BMA_MRA'),(292,'JA_NEIN','AUSCHALTUNG_BMA'),(293,'AUSLOESUNG_MELDER','AUSLOESUNG_DURCH_MELDER'),(294,'JA_NEIN','AUTO_NACHEINSPEISUNG_HV'),(295,'JA_NEIN','AUTO_NACHEINSPEISUNG_KV'),(296,'BAUART_BRFL','BAUART_BRFL'),(297,'BAUART_DAMPFKESSEL','BAUART_DAMPFKESSEL'),(298,'BAUART_TRAFO','BAUART_TRAFO'),(299,'BAUART_UMLUFT','BAUART_UMLUFT'),(300,'BAUART_VERDICHTER','BAUART_VERDICHTERS'),(301,'ANTRIEB_FBA','BEDIENUNG_SONNE'),(302,'JA_NEIN','BEFESTIGUNG_EINSEHB'),(303,'JA_NEIN','BEFESTIGUNG_EINSEHBAR'),(304,'BEFEUCHTUNGART','BEFEUCHTUNGART_KKS'),(305,'BEFEUCHTUNGART','BEFEUCHTUNGART_ZUAB'),(306,'BESONDERHEIT','BESONDERHEIT'),(307,'BETREIBER_EIGENTUEMER','BETREIBER_BHKW'),(308,'BETREIBER_EIGENTUEMER','BETREIBER_BRENNST'),(309,'BETREIBER_EIGENTUEMER','BETREIBER_NOTSTROM_NEA'),(310,'BETREIBER_EIGENTUEMER','BETREIBER_PHOTO'),(311,'BETRIEBSART_BOS','BETRIEBSART_BOS'),(312,'BETRIEBSWEISE','BETRIEBSWEISE'),(313,'BETRIEBSWEISE_SIBE','BETRIEBSWEISE_SIBE'),(314,'JA_NEIN','BLITZSTROMABL_NSHV'),(315,'JA_NEIN','BRANDFALLMATIX_VOR'),(316,'BRENNSTOFF_BHKW','BRENNSTOFF_BHKW'),(317,'BRUNNENNUTZUNG','BRUNNENNUTZUNG'),(318,'JA_NEIN','DATENFERNUEBERTRAGUNG_MSA'),(319,'EIGENSTROMVERBRAUCH','EIGENSTROMVERBRAUCH_BHKW'),(320,'EIGENSTROMVERBRAUCH','EIGENSTROMVERBRAUCH_BRENNST'),(321,'EIGENSTROMVERBRAUCH','EIGENSTROMVERBRAUCH_PHOTO'),(322,'BETREIBER_EIGENTUEMER','EIGENTUEMER_BHKW'),(323,'BETREIBER_EIGENTUEMER','EIGENTUEMER_BRENNST'),(324,'BETREIBER_EIGENTUEMER','EIGENTUEMER_NOTSTROM_NEA'),(325,'BETREIBER_EIGENTUEMER','EIGENTUEMER_PHOTO'),(326,'BETREIBER_EIGENTUEMER','EIGENTUEMER_WAERMEP'),(327,'JA_NEIN','EIGEN_NOTSTROM_SPR'),(328,'JA_NEIN','EXPLOSIONSSCHUTZ_DIG'),(329,'JA_NEIN','EX_BEREICH_GMS'),(330,'JA_NEIN','EX_BEREICH_USV'),(331,'FESTSTELLVORRICHTUNG','FESTSTELLVORRICHTUNG'),(332,'JA_NEIN','FEUERWEHRAUFZUG'),(333,'FILTERART_SF','FILTERART1'),(334,'FILTERART','FILTERART_DIG'),(335,'FILTERART_RSF','FILTERART_FA'),(336,'FILTERART','FILTERART_KKS'),(337,'FILTERART','FILTERART_TLS'),(338,'FILTERGROESSE','FILTERGROESSE_DIG'),(339,'FILTERGROESSE','FILTERGROESSE_KKS'),(340,'FILTERGROESSE','FILTERGROESSE_TLS'),(341,'FILTERKLASSE','FILTERKLASSE_DIG'),(342,'FILTERKLASSE','FILTERKLASSE_KKS'),(343,'FILTERKLASSE','FILTERKLASSE_TLS'),(344,'JA_NEIN','FLUCHTUER_STEUERUNG1'),(345,'JA_NEIN','FLUCHTUER_STEUERUNG2'),(346,'JA_NEIN','FLUCHTUER_STEUERUNG3'),(347,'JA_NEIN','FLUCHTUER_STEUERUNG4'),(348,'JA_NEIN','FLUCHTUER_STEUERUNG5'),(349,'JA_NEIN','FLUCHTUER_STEUERUNG'),(350,'JA_NEIN','FREQUENZUMFORMER_NA'),(351,'JA_NEIN','FREQUENZ_UMFORMER'),(352,'JA_NEIN','GASFÃœLLUNG'),(353,'JA_NEIN','GERAETE_GRUPPE_UV'),(354,'HEIZMEDIUM','HEIZMEDIUM1'),(355,'HEIZMEDIUM','HEIZMEDIUM'),(356,'JA_NEIN','INTEGRIERTER_DRUCKMIN'),(357,'ISOLIERUNG','ISOLIERUNG_MSA'),(358,'KAELTEMITTEL','KAELTEMITTEL_KEZ'),(359,'KAELTEMITTEL','KAELTEMITTEL_KKS'),(360,'KAELTEMITTEL','KAELTEMITTEL_KSA'),(361,'KAELTEMITTEL','KAELTEMITTEL_MSPLI'),(362,'KAELTEMITTEL','KAELTEMITTEL_WAERMEPUMPE'),(363,'BLITZSCHUTZKLASSE','\'KATEGORIE DES DRUCKBEHAEL_'),(364,'BLITZSCHUTZKLASSE','KATEGORIE_DRUCKBE_WASS'),(365,'KLASS_TUER','KLASSIFIZIERUNG1'),(366,'KLASS_TUER','KLASSIFIZIERUNG2'),(367,'KLASS_TUER','KLASSIFIZIERUNG'),(368,'ART_KOLLEKTOR','KOLLEKTORART'),(369,'JA_NEIN','KONDENSATPUMPE_KSA'),(370,'JA_NEIN','KONDENSATPUMPE_MSPLA'),(371,'JA_NEIN','KONDENSATPUMPE_MSPLI'),(372,'JA_NEIN','KONTI_MESS_SPEICH1'),(373,'JA_NEIN','KONTI_MESS_SPEICH2'),(374,'JA_NEIN','KONTI_MESS_SPEICH'),(375,'KUEHLMEDIUM','KUEHLMEDIUM_KEZ'),(376,'JA_NEIN','KUEHLUNG_ENTFEUCHTUNG_KKS'),(377,'JA_NEIN','KWKG_FOERDERUNG_BRENNST'),(378,'JA_NEIN','KWKG_FOERDERUNG'),(379,'LAGERORT','LAGERSTANDORT'),(380,'JA_NEIN','LECKAGEERKENNUNGSSYST_GASLOE'),(381,'JA_NEIN','LECKAGEUEBERWACHUNG'),(382,'JA_NEIN','LECKAGE_ERKENNUNG'),(383,'ART_LOESCHMITTEL','LOESCHMITTEL_BRFL'),(384,'JA_NEIN','LUFTSROEUEBERWACHUNG_DIG'),(385,'BEHAELTERMAT','MATERIAL_BEH'),(386,'JA_NEIN','MESSEINRICHTUNG_ENERGIE'),(387,'JA_NEIN','MESSEINRICHTUNG_PHOTO'),(388,'JA_NEIN','MISCHLUFTKAMMERN'),(389,'NEUT_MITTEL','NEUTRALISATIONS_MITTEL'),(390,'JA_NEIN','NOTLEUCHTE_MSA'),(391,'JA_NEIN','NOTLEUCHTE_NSHV'),(392,'JA_NEIN','NOTRUF_AUFZUG'),(393,'NUTZ_GEBAEUDE','NUTZUNGSART_GEBAEUDE'),(394,'JA_NEIN','OELAUFFANGSYSTEM_TRAFO'),(395,'JA_NEIN','OELFUERENDE_UNTERIRDISCH_TEILE'),(396,'JA_NEIN','OPFERANODE'),(397,'ORT_BEFESTIGUNG','ORT_BEFESTIGUNG'),(398,'PROBELAUF','PROBELAUF_NEA'),(399,'PUMPENTYP','PUMPENTYP'),(400,'JA_NEIN','RUECKENSCHUTZ'),(401,'RUECKF_BRUWA','RUECKFUERUNG_BRUNNENWASSER'),(402,'JA_NEIN','RUECKLAUFTTEMP_BEGRENZ'),(403,'JA_NEIN','SCHAUMZUMISCHUNG_SPR'),(404,'JA_NEIN','SCHLITZKABEL_BOS'),(405,'JA_NEIN','SICHERHEITSABSCHALT_PHOTO'),(406,'JA_NEIN','SICHERHEITSSTROMVERS_NEA'),(407,'JA_NEIN','SICHERHEITSSTROMVERS_SCHWUNG'),(408,'JA_NEIN','SICHERHEITSTROMVERS_USV'),(409,'JA_NEIN','SICHTECH_FUN'),(410,'JA_NEIN','SPEICHERLADESYSTEM'),(411,'STANDORT_BRUNNEN','STANDORT1'),(412,'STANDORT_BRUNNEN','STANDORT'),(413,'STEIGSCHUTZ','STEIGSCHUTZEINRICHTUNG'),(414,'JA_NEIN','STROMSTEUERENTLASTUNG_BRENNST'),(415,'JA_NEIN','STROMSTEUERENTLASTUNG'),(416,'JA_NEIN','STROMSTEUER_PHOTO'),(417,'JA_NEIN','SV_NETZ_NSHV'),(418,'NOTSTROM_SV','SV_UMSCHALTEINRICHTUNG_NEA'),(419,'TUERWAECHTER','TUER_WAECHTER'),(420,'JA_NEIN','UEBERSPANNUNGSCHUTZ_NSHV'),(421,'JA_NEIN','UEBERSPANNUNGSCHUTZ_UV'),(422,'UNTERGRUND','UNTERGRUNDMATERIAL'),(423,'VENTILATOR','VENTILATOREN_TYP_DIG'),(424,'UNTERGRUND','UNTERGRUNDMATERIAL1'),(425,'VENTILATOR','VENTILATOREN_TYP_ABL'),(426,'VERBRENNLUFT','VERBRENNUNGSLUFT'),(427,'JA_NEIN','VERDROSSELT_BLK'),(428,'VERSNETZ','VERSORGUNGSNETZ_UV'),(429,'VERWENDUNG_ASA','VERWENDUNGSZWECK_ASA'),(430,'VERWENDUNG_RGWA','VERWENDUNGSZWECK_WASSER'),(431,'JA_NEIN','VOLLGEKAPSELT_MSA'),(432,'JA_NEIN','WAERMEMENGENZAELER_ABGEER_WP'),(433,'JA_NEIN','WAERMEPUMPENFUNKTION_KSA'),(434,'WAERMEQUELLE','WAERMEQUELLE'),(435,'ART_WRG','WAERMERUECKART_ZUAB'),(436,'WANDSICH','WANDSICHERUNG'),(437,'ART_WASSER','WASSERART'),(438,'JA_NEIN','WASSERAUFBEREITUNG'),(439,'WERKSTOFF_N','WERKSTOFF'),(440,'JA_NEIN','ZAEHLEREINRICHTUNG_BREENNST'),(441,'JA_NEIN','ZAEHLEREINRICHTUNG'),(442,'ZENTRALE_ANSTEUERUNG','ZENTRALE_ANSTEUERUNG'),(443,'DOCUMEN','NACHW'),(444,'DOCUMEN','INBET'),(445,'DOCUMEN','REV'),(446,'DOCUMEN','EINW'),(447,'FILTERART','FILTER_LUFT_ART'),(448,'VENTILATOR','VENTILATOREN_TYP_DIG'),(449,'VENTILATOR','VENTILATOREN_TYP_ABL'),(450,'ART_ABWASSER','ART_ABWASSER'),(451,'ABWASSER_FORTLEITUNG','ABWASSER_FORTLEITUNG'),(452,'ART_LOESCHANLAGE','ART_LOESCHANLAGE'),(453,'ART_LOESCHMITTEL','LOESCHMITTEL_BRFL'),(454,'JA_NEIN','AUFSCHALTUNG_BMA'),(455,'JA_NEIN','AUSLOESUNG_DURCH_MELDER'),(456,'JA_NEIN','GASFUELLUNG'),(457,'JA_NEIN','KWKG_FOERDERUNG'),(458,'BLITZSCHUTZKLASSE','KATEGORIE_DES_DRUCKBEHAEL'),(459,'JA_NEIN','KWKG_FOERDERUNG_BRENNST'),(460,'JA_NEIN','LECKAGEERKENNUNGSSYST_GASLOE'),(461,'JA_NEIN','LUFTSROEUEBERWACHUNG_DIG'),(462,'JA_NEIN','OELAUFFANGSYSTEM_TRAFO'),(463,'JA_NEIN','OELFUERENDE_UNTERIRDISCH_TEILE'),(464,'POZESSI','PROZESSIST'),(465,'KAN_RM','KAN_RAUCH');
/*!40000 ALTER TABLE `bestand_option2attrib` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_options`
--

DROP TABLE IF EXISTS `bestand_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_options` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(50) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=840 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_options`
--

LOCK TABLES `bestand_options` WRITE;
/*!40000 ALTER TABLE `bestand_options` DISABLE KEYS */;
INSERT INTO `bestand_options` (`row`, `option`, `value`) VALUES (458,'JA_NEIN','Ja'),(459,'JA_NEIN','Nein'),(460,'ABWASSER_FORTLEITUNG','Versickerung'),(461,'ABWASSER_FORTLEITUNG','Kanalanschluss'),(462,'ABWASSER_FORTLEITUNG','Einleitung Gewässer'),(463,'ANBINDUNG_BOS','Luftschnittstelle/Außenantenne'),(464,'ANBINDUNG_BOS','eigene Basisstation'),(465,'ANBINDUNG_BOS','HF-Ankopplung'),(466,'ANBINDUNG_BOS','LWL'),(467,'ANSCHLUSS_WASSER_NETZ','mittelbar'),(468,'ANSCHLUSS_WASSER_NETZ','unmittelbar'),(469,'ANSCHLUSS','direkt '),(470,'ANSCHLUSS','indirekt'),(471,'ANSCHLUSS','Pufferbehälter/hydraulische Weiche'),(472,'ANTRIEB_FBA','manuell'),(473,'ANTRIEB_FBA','kraftbetätigt'),(474,'ANTRIEB','Treibscheibe (Seilaufzug)'),(475,'ANTRIEB','Hydraulisch'),(476,'ANTRIEB','Sonstiges'),(477,'ANTRIEBSART','pneumatisch'),(478,'ANTRIEBSART','elektrisch'),(479,'ANTRIEBSART','gasbetrieben'),(480,'ANTRIEBSART','sonstiges'),(481,'ANWENDUNGSBEREICH','Aufenthaltsraum'),(482,'ANWENDUNGSBEREICH','Technikraum'),(483,'ANWENDUNGSBEREICH','Trinkwasser'),(484,'ANWENDUNGSBEREICH','Schwimmbad'),(485,'ANWENDUNGSBEREICH','Heizung'),(486,'ANWENDUNGSBEREICH','Labor'),(487,'ANWENDUNGSBEREICH','Autowaschanlage'),(488,'ANWENDUNGSBEREICH','Küchentechnik'),(489,'ANWENDUNGSBEREICH','Sonstiges'),(490,'ANZ_FLUE','zweiflügelig'),(491,'ANZ_FLUE','nicht relevant'),(492,'ANZ_FLUE','einflügelig'),(493,'ART_ABWASSER','Regenwasser'),(494,'ART_ABWASSER','Schmutzwaser, mit Fäkalien'),(495,'ART_ABWASSER','Schmutzwaser, ohne Fäkalien'),(496,'ART_ABWASSER','Mischwasser'),(497,'ART_FBA','Fassadenleiter'),(498,'ART_AUSLOESUNG_DRA','manuell'),(499,'ART_AUSLOESUNG_DRA','automatisch'),(500,'ART_AUSLOESUNG_DRA','kombiniert'),(501,'ART_BEFESTIGUNG','verschraubt'),(502,'ART_BEFESTIGUNG','eingemauert'),(503,'ART_BEFESTIGUNG','geschweißt'),(504,'ART_BEFESTIGUNG','Sonstiges'),(505,'ART_BEHEIZ','indirekt'),(506,'ART_BEHEIZ','direkt'),(507,'ART_BETAETIG','Induktionsschleife'),(508,'ART_BETAETIG','Taster'),(509,'ART_BETAETIG','Kartenleser'),(510,'ART_BETAETIG','Bewegungsmelder'),(511,'ART_BETAETIG','Schlüsselschalter'),(512,'ART_BETAETIG','Transponder'),(513,'ART_BETAETIG','sonstiges'),(514,'ART_BRENNSTOFF','Gas'),(515,'ART_BRENNSTOFF','Heizöl'),(516,'ART_SPRECHANL','Lichtrufanlagen'),(517,'ART_SPRECHANL','Behinderten-Notruf'),(518,'ART_SPRECHANL','Türsprechanlagen'),(519,'ART_SPRECHANL','Haussprechanlagen'),(520,'ART_SPRECHANL','Videosprechanlagen'),(521,'ART_SPRECHANL','Lichtzeichenanlagen (Ampel)'),(522,'ART_SPRECHANL','Ruf-/Aufrufanlagen'),(523,'ART_SPRECHANL','Schwerhörigenanlagen'),(524,'ART_SPRECHANL','Mithöranlagen'),(525,'ART_SPRECHANL','Betriebsfunkanlagen'),(526,'ART_ERWAERM','Durchlauferhitzer'),(527,'ART_ERWAERM','Untertischgerät'),(528,'ART_ERWAERM','Kochendwassergerät'),(529,'ART_ERWAERM','sonstiges'),(530,'ART_SCHLIESSUNG','Obertürschließer'),(531,'ART_SCHLIESSUNG','Federband'),(532,'ART_SCHLIESSUNG','manuell'),(533,'ART_SCHLIESSUNG','sonstige'),(534,'ART_ZELLE','AFC'),(535,'ART_ZELLE','DMFC'),(536,'ART_ZELLE','PEMFC'),(537,'ART_ZELLE','PAFC'),(538,'ART_ZELLE','MCFC'),(539,'ART_ZELLE','SOFC'),(540,'ART_DACH','Flachdach'),(541,'ART_DACH','Pultdach'),(542,'ART_DACH','Schleppdach'),(543,'ART_DACH','Sattel-/Giebeldach'),(544,'ART_DACH','Walmdach'),(545,'ART_DACH','Mansarddach'),(546,'ART_DACH','Sonstiges'),(547,'ART_WAERMEVERTEILER','Hauptverteilung'),(548,'ART_WAERMEVERTEILER','Unterverteilung'),(549,'ART_ERSATZSTROM_SIBE','Einzelbatterie'),(550,'ART_ERSATZSTROM_SIBE','Zentralbatterie'),(551,'ART_ERSATZSTROM_SIBE','Sicherheitsstromversorgung'),(552,'ART_LOESCHANLAGE','Sprühwasser'),(553,'ART_LOESCHANLAGE','Sprinkleranlage'),(554,'ART_LOESCHANLAGE','Wassernebel'),(555,'ART_LOESCHANLAGE','sonstige'),(556,'ART_MEDIZINVERSORGUNG','Sauerstoff'),(557,'ART_MEDIZINVERSORGUNG','Stickstoff'),(558,'ART_MEDIZINVERSORGUNG','Helium'),(559,'ART_MEDIZINVERSORGUNG','Acetylen'),(560,'ART_MEDIZINVERSORGUNG','sonstige'),(561,'ART_MESSSYSTEM','Mehrkanal-System'),(562,'ART_MESSSYSTEM','Ansaugsystem'),(563,'ART_MESSSYSTEM','sonstige'),(564,'ART_TUER_TOR','Falttür/tor'),(565,'ART_TUER_TOR','Schiebetür/tor'),(566,'ART_TUER_TOR','Rolltor'),(567,'ART_TUER_TOR','Drehflügeltür/tor '),(568,'ART_TUER_TOR','Sektionaltor'),(569,'ART_TUER_TOR','Garagentor'),(570,'ART_TUER_TOR','Karuselltür'),(571,'AUFSTELLART','Schrägdach Boden'),(572,'AUFSTELLART','Fassade'),(573,'AUFSTELLART','Sattel-/Giebeldach'),(574,'AUFSTELLART','Grundstück'),(575,'AUSLOESUNG_MELDER','integriert'),(576,'AUSLOESUNG_MELDER','separat'),(577,'AUSLOESUNG_MELDER','sonstige'),(578,'BAUART_BRFL','Dauerdrucklöscher'),(579,'BAUART_BRFL','Aufladelöscher'),(580,'BAUART_DAMPFKESSEL','Heißwasserkessel'),(581,'BAUART_DAMPFKESSEL','Niederdruckdampfkessel < 1 bar'),(582,'BAUART_DAMPFKESSEL','Hochdruckdampfkessel'),(583,'BAUART_TRAFO','Öl'),(584,'BAUART_TRAFO','Gießharz (trocken)'),(585,'BAUART_UMLUFT','Gebläse'),(586,'BAUART_UMLUFT','Induktion'),(587,'BAUART_VERDICHTER','Schraubenverdichter'),(588,'BAUART_VERDICHTER','Scrollverdichter'),(589,'BAUART_VERDICHTER','Kolbenverdichter'),(590,'BAUART_VERDICHTER','Rotationsverdichter'),(593,'BEFEUCHTUNGART','Dampf'),(594,'BEFEUCHTUNGART','Umlaufsprüh'),(595,'BEFEUCHTUNGART','Waben'),(596,'BEFEUCHTUNGART','sonstige'),(597,'BEFEUCHTUNGART','Keine'),(598,'BESONDERHEIT','Dachziegel'),(599,'BESONDERHEIT','Blechdach'),(600,'BESONDERHEIT','Gründach'),(601,'BESONDERHEIT','Kunststoff'),(602,'BESONDERHEIT','Kies'),(603,'BESONDERHEIT','Bitum'),(604,'BESONDERHEIT','sonstige'),(605,'BETREIBER_EIGENTUEMER','BLB'),(606,'BETREIBER_EIGENTUEMER','Mieter'),(607,'BETREIBER_EIGENTUEMER','Contractor'),(608,'BETRIEBSART_BOS','TMO'),(609,'BETRIEBSART_BOS','DMO'),(610,'BETRIEBSART_BOS','TMO+DMO'),(611,'BETRIEBSWEISE','monovalent'),(612,'BETRIEBSWEISE','bivalent'),(613,'BETRIEBSWEISE','Kaskade'),(614,'BETRIEBSWEISE_SIBE','Dauerbetrieb'),(615,'BETRIEBSWEISE_SIBE','bedarfsweiser Betrieb'),(616,'BETRIEBSWEISE_SIBE','Mischform'),(617,'BRENNSTOFF_BHKW','gasbetrieben'),(618,'BRENNSTOFF_BHKW','Heizöl'),(619,'BRUNNENNUTZUNG','Trinkwassergewinnung'),(620,'BRUNNENNUTZUNG','Wärmepumpe'),(621,'BRUNNENNUTZUNG','Kühlung'),(622,'BRUNNENNUTZUNG','Bewässerung'),(623,'EIGENSTROMVERBRAUCH','Einspeisung ö. Netz'),(624,'EIGENSTROMVERBRAUCH','100% Eigenstromverbrauch'),(625,'FESTSTELLVORRICHTUNG','elektrisch'),(626,'FESTSTELLVORRICHTUNG','mechanisch'),(627,'FESTSTELLVORRICHTUNG','sonstige'),(628,'FILTERART','Taschenfilter'),(629,'FILTERART','Kompakt-/Kassettenfilter'),(630,'FILTERART','Mattenfilter'),(631,'FILTERART','Aktivkohlefilter'),(632,'FILTERART','Rollbandfilter'),(633,'FILTERART_RSF','ohne Rückspülung'),(634,'FILTERART_RSF','manuell rückspülbar'),(635,'FILTERART_RSF','automatisch rückspülend'),(636,'FILTERART_SF','Sand'),(637,'FILTERART_SF','Kies'),(638,'FILTERART_SF','Mehrschicht'),(639,'FILTERGROESSE','592x592'),(640,'FILTERGROESSE','490x592'),(641,'FILTERGROESSE','287x592'),(642,'FILTERGROESSE','287x287'),(643,'FILTERGROESSE','592x287'),(644,'FILTERGROESSE','592x490'),(645,'FILTERGROESSE','490x490'),(646,'FILTERGROESSE','Freifeld'),(647,'FILTERKLASSE','G1'),(648,'FILTERKLASSE','G2'),(649,'FILTERKLASSE','G3'),(650,'FILTERKLASSE','G4'),(651,'FILTERKLASSE','M5 (F5)'),(652,'FILTERKLASSE','M6 (F6)'),(653,'FILTERKLASSE','H7'),(654,'FILTERKLASSE','H8'),(655,'FILTERKLASSE','H9'),(656,'FILTERKLASSE','E10'),(657,'FILTERKLASSE','E11'),(658,'FILTERKLASSE','E12'),(659,'FILTERKLASSE','H13'),(660,'FILTERKLASSE','H14'),(661,'FILTERKLASSE','U15'),(662,'FILTERKLASSE','U16'),(663,'FILTERKLASSE','U17'),(664,'WERKSTOFF_N','Beton'),(665,'WERKSTOFF_N','Edelstahl'),(666,'WERKSTOFF_N','Kunststoff'),(667,'WERKSTOFF_N','sonstiges'),(679,'BLITZSCHUTZKLASSE','I'),(680,'BLITZSCHUTZKLASSE','II'),(681,'BLITZSCHUTZKLASSE','III'),(682,'BLITZSCHUTZKLASSE','IV'),(685,'ANWENDUNGSZWECK','Leitwarten'),(686,'ANWENDUNGSZWECK','Rechnerräume'),(687,'ANWENDUNGSZWECK','zur Raumluftklimatisierung'),(688,'ANWENDUNGSZWECK','für Klimasplitgeräte'),(689,'ANWENDUNGSZWECK','sonstiges'),(690,'ANWENDUNGSZWECK','Küchenbereich'),(691,'ART_FBA','Befahranlage'),(692,'HEIZMEDIUM','Holz'),(693,'HEIZMEDIUM','Flüssiggas'),(694,'HEIZMEDIUM','Holzhackschnitzel'),(695,'HEIZMEDIUM','Erdgas'),(696,'HEIZMEDIUM','Holzpellets'),(697,'HEIZMEDIUM','Kohle'),(698,'HEIZMEDIUM','Heizöl'),(699,'ISOLIERUNG','Luft'),(700,'ISOLIERUNG','Gas'),(701,'ISOLIERUNG','Vakuum'),(702,'KAELTEMITTEL','R-1270'),(703,'KAELTEMITTEL','R-134A'),(704,'KAELTEMITTEL','R-152A'),(705,'KAELTEMITTEL','R-22'),(706,'KAELTEMITTEL','R-23'),(707,'KAELTEMITTEL','R-290'),(708,'KAELTEMITTEL','R-32'),(709,'KAELTEMITTEL','R-404A'),(710,'KAELTEMITTEL','R-407A'),(711,'KAELTEMITTEL','R-407C'),(712,'KAELTEMITTEL','R-407F'),(713,'KAELTEMITTEL','R-410A'),(714,'KAELTEMITTEL','R-417A'),(715,'KAELTEMITTEL','R-422A'),(716,'KAELTEMITTEL','R-422D'),(717,'KAELTEMITTEL','R-427A'),(718,'KAELTEMITTEL','R-437A'),(719,'KAELTEMITTEL','R-43A'),(720,'KAELTEMITTEL','R-507'),(721,'KAELTEMITTEL','R-600A'),(722,'KAELTEMITTEL','R-717'),(723,'KAELTEMITTEL','R-744'),(724,'KLASS_TUER','Rauchschutz'),(725,'KLASS_TUER','T30'),(726,'KLASS_TUER','T30-RS'),(727,'KLASS_TUER','T60'),(728,'KLASS_TUER','T90'),(729,'KLASS_TUER','T90-RS'),(730,'KLASS_TUER','T120'),(731,'KLASS_TUER','T120-RS'),(732,'ART_KOLLEKTOR','Flachkollektor'),(733,'ART_KOLLEKTOR','Röhrenkollektor'),(734,'ART_KOLLEKTOR','Speicherkollektor'),(735,'ART_KOLLEKTOR','Hybridkollektor'),(736,'ART_KOLLEKTOR','Luftkollektor'),(737,'KUEHLMEDIUM','Wasser'),(738,'KUEHLMEDIUM','Wasser / Glykolgemisch'),(739,'KUEHLMEDIUM','Luft (Direktverdampfer)'),(740,'LAGERORT','außerhalb Gebäude, oberirdisch'),(741,'LAGERORT','außerhalb Gebäude, unterirdisch'),(742,'LAGERORT','im Gebäude'),(743,'ART_LOESCHMITTEL','Pulver'),(744,'ART_LOESCHMITTEL','Wasser / Schaum'),(745,'ART_LOESCHMITTEL','CO2: 2kg'),(746,'ART_LOESCHMITTEL','CO2: 5kg'),(747,'BEHAELTERMAT','Kunststoff'),(748,'BEHAELTERMAT','Stahl'),(749,'BEHAELTERMAT','sonstiges'),(750,'NEUT_MITTEL','Kalkstein'),(751,'NEUT_MITTEL','Dolomit'),(752,'NEUT_MITTEL','Marmor'),(753,'NEUT_MITTEL','Magnesiumoxid'),(754,'NEUT_MITTEL','sonstiges'),(755,'NUTZ_GEBAEUDE','öffentlich'),(756,'NUTZ_GEBAEUDE','nicht öffentlich'),(757,'ORT_BEFESTIGUNG','Dach'),(758,'ORT_BEFESTIGUNG','Fassade'),(759,'ORT_BEFESTIGUNG','Innenwand'),(760,'ORT_BEFESTIGUNG','sonstiges'),(761,'PROBELAUF','gegen Netz'),(762,'PROBELAUF','gegen Widerstände'),(763,'PUMPENTYP','Saugpumpe, selbstansaugend'),(764,'PUMPENTYP','Unterwasserpumpe'),(765,'RUECKF_BRUWA','Versickerung'),(766,'RUECKF_BRUWA','Verrieselung'),(767,'RUECKF_BRUWA','Schluckbrunnen'),(768,'RUECKF_BRUWA','keine'),(769,'STANDORT_BRUNNEN','innen, unterirdisch'),(770,'STANDORT_BRUNNEN','außen, unterirdisch'),(771,'STANDORT_BRUNNEN','innen, oberirdisch'),(772,'STEIGSCHUTZ','keine'),(773,'STEIGSCHUTZ','Laufschiene'),(774,'STEIGSCHUTZ','Seilsicherung'),(775,'NOTSTROM_SV','manuell'),(776,'NOTSTROM_SV','automatisch'),(777,'TUERWAECHTER','Einhand'),(778,'TUERWAECHTER','Stange'),(779,'TUERWAECHTER','keine'),(780,'UNTERGRUND','Beton'),(781,'UNTERGRUND','Holz'),(782,'UNTERGRUND','Mauerwerk'),(783,'UNTERGRUND','Stahl'),(784,'UNTERGRUND','sonstiges'),(785,'VENTILATOR','axial'),(786,'VENTILATOR','radial'),(787,'VERBRENNLUFT','raumluftabhängig'),(788,'VERBRENNLUFT','raumluftunabhängig'),(789,'VERSNETZ','Allgemeinstromversorgung (AV)'),(790,'VERSNETZ','Sicherheitsstromversorgung (SV)'),(791,'VERSNETZ','SV und AV'),(792,'VERWENDUNG_ASA','Arbeitsplatzabsaugung'),(793,'VERWENDUNG_ASA','Späneabsaugung'),(794,'VERWENDUNG_ASA','Gefahrstoffschrank'),(795,'VERWENDUNG_ASA','sonstiges'),(796,'VERWENDUNG_RGWA','Gartenbewässerung'),(797,'VERWENDUNG_RGWA','Nicht-Trinkwasseranlagen'),(798,'VERWENDUNG_RGWA','sonstiges'),(799,'WAERMEQUELLE','Erdkollektor'),(800,'WAERMEQUELLE','Erdsonde'),(801,'WAERMEQUELLE','Wasser / Luft'),(802,'WAERMEQUELLE','Luft / Luft'),(803,'WAERMEQUELLE','Eisspeicher'),(804,'WAERMEQUELLE','Sole / Wasser'),(805,'ART_WRG','Kreislaufverbundsystem'),(806,'ART_WRG','Plattenwärmetauscher'),(807,'ART_WRG','Rohrbündelwärmetauscher'),(808,'WANDSICH','Doppelwandig'),(809,'WANDSICH','Einwandig'),(810,'ART_WASSER','Regen'),(811,'ART_WASSER','Grau'),(812,'ZENTRALE_ANSTEUERUNG','Windsensor'),(813,'ZENTRALE_ANSTEUERUNG','Lichtsensor'),(814,'ZENTRALE_ANSTEUERUNG','Wind-/Lichtsensor'),(815,'ZENTRALE_ANSTEUERUNG','sonstiges'),(816,'ZENTRALE_ANSTEUERUNG','keine'),(817,'DOCUMEN','vorhanden'),(818,'DOCUMEN','nicht vorhanden'),(821,'POZESSI','Umzugsmanagement'),(822,'POZESSI','Unfallanzeigen'),(823,'POZESSI','Vermietung von Räumen'),(824,'POZESSI','Schadensmeldung Personenschäden'),(825,'POZESSI','Schadensmeldung Sachschäden'),(826,'POZESSI','Fundsachen'),(827,'POZESSI','Ausstattung von Räumen'),(828,'POZESSI','Postabfertigung'),(829,'ART_WRG','Gegenstromtauscher'),(830,'ART_WRG','Rotationswärmetauscher'),(831,'ART_WRG','Akku-Block-Wärmetauscher'),(837,'KAN_RM','mit Aufschaltung auf BMA'),(838,'KAN_RM','ohne Aufschaltung auf BMA'),(839,'KAN_RM','Keine');
/*!40000 ALTER TABLE `bestand_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bestand_prozess`
--

DROP TABLE IF EXISTS `bestand_prozess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bestand_prozess` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `merkmal_kurz` varchar(50) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` int(1) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  `bezeichner_kurz` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bestand_prozess`
--

LOCK TABLES `bestand_prozess` WRITE;
/*!40000 ALTER TABLE `bestand_prozess` DISABLE KEYS */;
/*!40000 ALTER TABLE `bestand_prozess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bezeichner`
--

DROP TABLE IF EXISTS `bezeichner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bezeichner` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `bezeichner_lang` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `din_276` varchar(10) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bezeichner`
--

LOCK TABLES `bezeichner` WRITE;
/*!40000 ALTER TABLE `bezeichner` DISABLE KEYS */;
/*!40000 ALTER TABLE `bezeichner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bezeichner_help`
--

DROP TABLE IF EXISTS `bezeichner_help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bezeichner_help` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `text` varchar(2064) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bezeichner_help`
--

LOCK TABLES `bezeichner_help` WRITE;
/*!40000 ALTER TABLE `bezeichner_help` DISABLE KEYS */;
/*!40000 ALTER TABLE `bezeichner_help` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bezeichner_settings`
--

DROP TABLE IF EXISTS `bezeichner_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bezeichner_settings` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `devider` int(10) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bezeichner_settings`
--

LOCK TABLES `bezeichner_settings` WRITE;
/*!40000 ALTER TABLE `bezeichner_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bezeichner_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changelog`
--

DROP TABLE IF EXISTS `changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changelog` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(15) NOT NULL,
  `merkmal_kurz` varchar(30) NOT NULL,
  `old` varchar(255) DEFAULT NULL,
  `new` varchar(255) DEFAULT NULL,
  `user` varchar(255) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changelog`
--

LOCK TABLES `changelog` WRITE;
/*!40000 ALTER TABLE `changelog` DISABLE KEYS */;
/*!40000 ALTER TABLE `changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gewerk2bezeichner`
--

DROP TABLE IF EXISTS `gewerk2bezeichner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gewerk2bezeichner` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `gewerk_kurz` varchar(30) NOT NULL,
  `bezeichner_kurz` varchar(30) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=1737 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gewerk2bezeichner`
--

LOCK TABLES `gewerk2bezeichner` WRITE;
/*!40000 ALTER TABLE `gewerk2bezeichner` DISABLE KEYS */;
INSERT INTO `gewerk2bezeichner` (`row`, `gewerk_kurz`, `bezeichner_kurz`) VALUES (1364,'ABLUFT','ALFTR'),(1368,'ANSCHLAGEIN','APA'),(1369,'ANSCHLAGEIN','API'),(1370,'ABSAUG','ASA'),(1371,'AWGSONSTIGE','ASE'),(1373,'HEBE','AWH'),(1374,'AWGSONSTIGE','BE'),(1375,'BHKW','BHKW'),(1376,'NSHV','BLK'),(1377,'BLITZERD','BLZI'),(1378,'BLITZERD','BLZA'),(1379,'GEBFUNK','BOS'),(1382,'BRUNNEN','BRU'),(1383,'FERNSONST','BSA'),(1384,'LUFTSONST','BSKM'),(1385,'LUFTSONST','BSKA'),(1386,'TUERBRMAN','BST'),(1387,'TUERBRMAN','BSTOZ'),(1388,'TUERBRMANFSA','FSNZ'),(1389,'TUERBRMANFSA','BSTF'),(1390,'TUERBRKRA','BSTK'),(1391,'TUERINNKRA','ITUERK'),(1392,'TUERAUSSKRA','ATUERK'),(1393,'TUERAUSSMAN','ATUER'),(1395,'LUFTSONST','BSV'),(1397,'COWARN','COWA'),(1400,'AWGSONSTIGE','NE'),(1401,'AWGSONSTIGE','DE'),(1402,'TRINKWAVER','DEA'),(1405,'DOSHEIZ','DOAH'),(1407,'TRINKWAWAERM','DWT'),(1408,'BAUSONSTIGE','DZ'),(1412,'EINBRUEBER','EMA'),(1413,'ABSCHEID','SAWSG'),(1414,'ABSCHEID','SA'),(1416,'ABSCHEID','LFAWSG'),(1417,'ABSCHEID','LFA'),(1418,'ABSCHEID','KA'),(1419,'ABSCHEID','FAWSG'),(1420,'BAUSONSTIGE','FAM'),(1423,'FENSTERMAN','FF'),(1426,'GASVERSORG','FGUB'),(1428,'HEBE','GWH'),(1429,'HEBE','FKH'),(1431,'BRENNSTOFFVER','FLTB'),(1432,'SIBE','NBS'),(1433,'SIBE','NBD'),(1434,'SIBE','FPSU'),(1435,'SIBE','FPDU'),(1436,'SIBE','SIEZ'),(1437,'SIBE','SIE'),(1441,'TRINKWAVER','RSFM'),(1442,'TRINKWAVER','RSFA'),(1444,'TUERAUSSMAN','FT'),(1445,'TUERAUSSKRA','FTK'),(1446,'TUERAUSSKRA','FTSA'),(1447,'TUERINNKRA','FTSI'),(1448,'ELEKSCHLIESS','FTEI'),(1449,'ELEKSCHLIESS','FTEA'),(1452,'NSHV','GHV'),(1453,'GLT','GLT'),(1458,'HEBEBUE','HB'),(1459,'TRFEULOE','HFLWN9'),(1460,'TRFEULOE','HFLWN6'),(1461,'TRFEULOE','HFLW9'),(1462,'TRFEULOE','HFLW6'),(1463,'TRFEULOE','HFLS9'),(1464,'TRFEULOE','HFLS6'),(1465,'TRFEULOE','HFLF6'),(1466,'TRFEULOE','HFLF3'),(1467,'TRFEULOE','HFLD9'),(1468,'TRFEULOE','HFLD12'),(1469,'TRFEULOE','HFLC5'),(1470,'TRFEULOE','HFLC2'),(1471,'TRFEULOE','HFLB9'),(1472,'TRFEULOE','HFLB6'),(1473,'TRFEULOE','HFLB4'),(1474,'TRFEULOE','HFLB3'),(1475,'TRFEULOE','HFLB2'),(1476,'TRFEULOE','HFLB1'),(1477,'TRFEULOE','HFLB12'),(1478,'TRFEULOE','HFLA9'),(1479,'TRFEULOE','HFLA6'),(1480,'TRFEULOE','HFLA4'),(1481,'TRFEULOE','HFLA3'),(1482,'TRFEULOE','HFLA2'),(1483,'TRFEULOE','HFLA1'),(1484,'TRFEULOE','HFLA12'),(1486,'WASSERKE','HKO'),(1489,'WASSERKE','HKG'),(1490,'WASSERKE','HKGG'),(1493,'TRINKWAVER','HMA'),(1494,'BRENNSTOFFVER','HOL'),(1495,'WARMEVERTEIL','HV'),(1497,'AWGSONSTIGE','HWZ'),(1499,'LUFTSONST','KD'),(1500,'KAELTEERZ','KEZ'),(1501,'KOMPKLIMA','KKS'),(1505,'WAERMEPU','WP'),(1508,'KAELTEV','KV'),(1510,'DIGESTOR','LAZ'),(1511,'DIGESTOR','LAB'),(1512,'PERSLAST','PAS'),(1513,'PERSLAST','PAH'),(1517,'STEIGLEI','LEI'),(1518,'OFGKG','GKGG'),(1519,'OFGKG','GKGE'),(1520,'DRUCKLU','DLVZ'),(1521,'DRUCKLU','DLVV'),(1522,'DRUCKLU','DLVD'),(1523,'GASVERST','GVT'),(1524,'GASVERST','GVZT'),(1525,'GASVERST','GVDT'),(1527,'SICHSCHRA','ABLC'),(1528,'KLETWAND','KLTR'),(1529,'SPRECHRUF','BWN'),(1537,'WARMESONS','LUEH'),(1541,'SCHALTHMSP','MSA'),(1542,'SCHALTHMSP','MSAG'),(1543,'MSRHEIZ','MSR'),(1544,'MSRLUEFT','MSR'),(1546,'KONDNEUT','NAH'),(1547,'BRANDSONSTIGE','NRA'),(1548,'SCHALTHMSP','NSHV'),(1551,'BLITZERD','PTAS'),(1552,'BLITZERD','PTA'),(1553,'PVA','PVA'),(1554,'WARMESONS','RBGLH'),(1555,'REGENGRAUWA','RGWA'),(1557,'TUERINNKRA','RL'),(1558,'UMLUFT','RLTU'),(1559,'ZUABLUFT','RLTK'),(1560,'ZULUFT','RLT'),(1561,'LUFTSCHL','TLSLA'),(1562,'ROLLREGA','RORG'),(1563,'AWGSONSTIGE','ROT'),(1564,'AWGSONSTIGE','RRB'),(1565,'SCHUVORH','RSRZ'),(1566,'AWGSONSTIGE','RSV'),(1567,'TUERAUSSKRA','RT'),(1568,'MRWA','RWAM'),(1569,'MRWA','RWAG'),(1570,'NATRAUAB','RWAN'),(1571,'SPRACHAL','SAA'),(1572,'KRAN','SAK'),(1573,'SCHWIMMB','SBTEIN'),(1575,'KSA','SKG'),(1576,'MULTISPL','MSPLA'),(1578,'SPIELPLA','SPPLGR'),(1582,'WASSLOE','SPRN'),(1583,'SPORTGER','SPRTGR'),(1584,'SCHRANKE','SRA'),(1585,'WARMESONS','SSO'),(1587,'WARMESONS','SSF'),(1588,'SONNE','VDAK'),(1589,'SONNE','SSK'),(1591,'ANSCHLAGEIN','SSS'),(1592,'TUERAUSSKRA','ST'),(1593,'AWGSONSTIGE','SVA'),(1594,'TRINKWAWAERM','ZSP'),(1595,'TRINKWAWAERM','SWT'),(1597,'TRAFO','TFOF'),(1598,'TRAFO','TFO'),(1599,'SOLAR','THS'),(1601,'TREPPLIFT','TL'),(1603,'FERNANT','TVE'),(1604,'TRENNSPO','TVH'),(1605,'DESINFEKT','TWHS'),(1606,'TRINKWAVER','TWVA'),(1608,'LOEWAANL','UFH'),(1609,'LOEWAANL','UEFH'),(1610,'LUFTSONST','UESK'),(1611,'UMWEHR','UMW'),(1613,'NEA','USVDS'),(1622,'NSHV','UVU'),(1623,'NSHV','UVS'),(1624,'NSHV','UVA'),(1627,'WANDHYNA','WDNSDM'),(1628,'WANDHYNA','WDNSDA'),(1629,'WANDHYNA','WDNS'),(1630,'WANDHYNA','WDNFDM'),(1631,'WANDHYNA','WDNFDA'),(1632,'WANDHYNA','WDNF'),(1633,'WANDHYNATR','WDNTSDM'),(1634,'WANDHYNATR','WDNTSDA'),(1635,'WANDHYNATR','WDNTS'),(1636,'WANDHYNATR','WDNTFDM'),(1637,'WANDHYNATR','WDNTFDA'),(1638,'WANDHYNATR','WDNTF'),(1639,'WANDHYTR','WDTS'),(1640,'WANDHYTR','WDTF'),(1641,'FERNWAERM','WUEGO'),(1642,'FERNWAERM','WUEG'),(1645,'GASTH','GTH'),(1646,'TRFEULOE','FLWN'),(1647,'TRFEULOE','FLW'),(1648,'TRFEULOE','FLS'),(1649,'TRFEULOE','FLF'),(1650,'TRFEULOE','FLD'),(1651,'TRFEULOE','FLC'),(1652,'TRFEULOE','FLB'),(1653,'TRFEULOE','FLA'),(1654,'ABLUFT','ABL'),(1655,'TUERBRMAN','BSTKU'),(1656,'DACH1','DCR'),(1659,'WARMESONS','DBPF'),(1660,'BRANDSONSTIGE','DEAL'),(1661,'TUERAUSSKRA','FTST'),(1665,'TRFEULOE','KSPR'),(1666,'ABLUFT','KABL'),(1667,'ZULUFT','LUBF'),(1668,'MRWA','MRA'),(1671,'BRUNNEN','ZIS'),(1680,'SICHSCHRA','LGFLSIR'),(1681,'SICHSCHRA','LGFLSIF'),(1682,'GASVERSORG','FLVB'),(1683,'SICHSCHRA','LGASAR'),(1685,'UMLUFT','RLTUG'),(1686,'UMLUFT','RLTUH'),(1713,'BAUWERK','KMG'),(1714,'BAUWERK','TNG'),(1716,'TUERBRKRA','BSTT'),(1717,'SICHSCHRA','ABLCO'),(1718,'ABSAUG','ASAO'),(1724,'TRFEULOE','HFLALL'),(1725,'AWGSONSTIGE','WARUE'),(1726,'BRANDMELD','BMA'),(1727,'BRANDMELD','BMAV'),(1728,'WASSERAUF','DOA'),(1730,'WASSERAUF','ESA'),(1733,'REGENGRAUWA','GWB'),(1734,'ABSCHEID','FA'),(1735,'MASCHBUE','BEI'),(1736,'TUERINNMAN','ITUER');
/*!40000 ALTER TABLE `gewerk2bezeichner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gewerke`
--

DROP TABLE IF EXISTS `gewerke`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gewerke` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `gewerk_kurz` varchar(30) NOT NULL,
  `gewerk_lang` varchar(255) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=855 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gewerke`
--

LOCK TABLES `gewerke` WRITE;
/*!40000 ALTER TABLE `gewerke` DISABLE KEYS */;
INSERT INTO `gewerke` (`row`, `gewerk_kurz`, `gewerk_lang`, `parent`) VALUES (645,'ZENTRALE','Standard (IFC4 DIN 276)',NULL),(646,'AWGANL','Abwasser-, Wasser-, Gasanlagen (410)','ZENTRALE'),(647,'BAUWERK','Bauwerk und Baukonstruktionen (300)','ZENTRALE'),(648,'BRANDSCH','Brandschutz','ZENTRALE'),(649,'ELEKTR','Starkstromanlagen (441)','ZENTRALE'),(650,'FERNMEL','Fernmelde- und informationstechnische Anlagen (450)','ZENTRALE'),(651,'FOERDER','Förderanlagen (460)','ZENTRALE'),(652,'LUFTTECHN','Lufttechnische Anlagen (430)','ZENTRALE'),(653,'NUTZSPEZ','Nutzungsspezifische Anlagen und Ausstattungen (470)','ZENTRALE'),(654,'WAERME','Wärmeversorgungsanlagen (420)','ZENTRALE'),(655,'ABWASSER','Abwasseranlagen (410)','ZENTRALE,AWGANL'),(656,'WASSER','Wasseranlagen (412)','ZENTRALE,AWGANL'),(657,'GASANLAGE','Gasversorgungsanlage (413)','ZENTRALE,AWGANL'),(658,'HYGIENE','Hygienische Einrichtungen','ZENTRALE,AWGANL'),(659,'AWGSONSTIGE','Abwasser-, Wasser-, Gasanlagen, sonstiges (419)','ZENTRALE,AWGANL'),(660,'ANSCHLAG','Anschlagpunkte','ZENTRALE,BAUWERK'),(661,'TUERTOR','Türe/Tore','ZENTRALE,BAUWERK'),(662,'FENSTER','Fenster','ZENTRALE,BAUWERK'),(663,'LEITER','Leitern','ZENTRALE,BAUWERK'),(664,'SONNENSCH','Sonnenschutzanlage','ZENTRALE,BAUWERK'),(665,'UMWEHRUNG','Umwehrungen','ZENTRALE,BAUWERK'),(666,'SCHLIESS','Schließungen mit Batterie','ZENTRALE,BAUWERK'),(667,'DACH','Dach','ZENTRALE,BAUWERK'),(668,'BAUSONSTIGE','Sonstige','ZENTRALE,BAUWERK'),(669,'FEUERSELBST','Feuerlöschanlage, selbsttätig','ZENTRALE,BRANDSCH'),(670,'BRANDVERM','Brandvermeidungsanlage','ZENTRALE,BRANDSCH'),(671,'FEUERNSELBST','Feuerlöschanlage, nicht selbsttätig','ZENTRALE,BRANDSCH'),(672,'NRWA','Natürlicher Rauchabzug (NRWA)','ZENTRALE,BRANDSCH'),(674,'BRANDSONSTIGE','Sonstige','ZENTRALE,BRANDSCH'),(675,'NIEDERSP','Niederspannungsinstallation','ZENTRALE,ELEKTR'),(676,'BLITZSCHUTZ','Blitzschutz- und Erdungsanlagen','ZENTRALE,ELEKTR'),(677,'MITTELSP','Hoch- und Mittelspannungsanlagen','ZENTRALE,ELEKTR'),(678,'EIGENSTROM','Eigenstromerzeugung','ZENTRALE,ELEKTR'),(679,'SIBELEUCH','Sicherheitsbeleuchtungsanlagen','ZENTRALE,ELEKTR'),(680,'ELSONSTIGE','elektrische Anlagen, sonstiges','ZENTRALE,ELEKTR'),(681,'SICHSTROM','Sicherheitsstromversorgungsanlagen/Notstrom','ZENTRALE,ELEKTR'),(682,'LTKANLAGE','Lüftungs-, Teilklima- oder Klimaanlage','ZENTRALE,LUFTTECHN'),(683,'MRA','Maschinelle Entrauchungs- und Wärmeabzugsanlage (MRA)','ZENTRALE,LUFTTECHN'),(684,'DRA','Überdruckbelüftungsanlage / Rauchschutz-Druckanlage (DRA)','ZENTRALE,LUFTTECHN'),(685,'SPLITKLIMA','Klima-Split-Anlage / Multi-Splitanlage','ZENTRALE,LUFTTECHN'),(686,'KAELTE','Kälteerzeugungsanlage','ZENTRALE,LUFTTECHN'),(687,'KAELTEVERT','Kälteverteilung','ZENTRALE,LUFTTECHN'),(688,'DAMPF','Dampferzeuger','ZENTRALE,LUFTTECHN'),(689,'MSRLUFT','MSR-Technik','ZENTRALE,LUFTTECHN'),(690,'WARMEERZ','Wärmeerzeugung','ZENTRALE,WAERME'),(691,'HEIZWASSAUF','Heizwasser-Aufbereitungsanlagen','ZENTRALE,WAERME'),(692,'ABGAS','Abgasanlagen','ZENTRALE,WAERME'),(693,'BRENNSTOFFV','Brennstoffversorgungsanlage','ZENTRALE,WAERME'),(694,'WAERMEVERT','Wärmeverteilung','ZENTRALE,WAERME'),(695,'TRINKWASSERW','Trinkwassererwärmungsanlagen','ZENTRALE,WAERME'),(696,'MSRWAERME','MSR-Technik','ZENTRALE,WAERME'),(697,'KUECHE','Küchentechnik','ZENTRALE,NUTZSPEZ'),(698,'WAESCHE','Wäscherei und Reinigung','ZENTRALE,NUTZSPEZ'),(699,'MEDIEN','Medienversorgung','ZENTRALE,NUTZSPEZ'),(700,'MEDIZIN','Medizin- und Labortechnik','ZENTRALE,NUTZSPEZ'),(701,'SPORT','Turngeräte, Sportgeräte','ZENTRALE,NUTZSPEZ'),(702,'NUTZSONSTIGE','Nutzungsspezifische Anlagen, sonstiges','ZENTRALE,NUTZSPEZ'),(703,'TUERAUSSMAN','Außentür/-Tor manuell betätigt','ZENTRALE,BAUWERK,TUERTOR'),(704,'TUERAUSSKRA','Außentür/-Tor kraftbetätigt','ZENTRALE,BAUWERK,TUERTOR'),(705,'TUERINNMAN','Innentür/-Tor manuell betätigt','ZENTRALE,BAUWERK,TUERTOR'),(706,'TUERINNKRA','Innentür/-Tor kraftbetätigt','ZENTRALE,BAUWERK,TUERTOR'),(707,'TUERBRMAN','Brand-/Rauchschutztür/-Tor manuell','ZENTRALE,BAUWERK,TUERTOR'),(708,'TUERBRMANFSA','Brand-/Rauchschutztür/-Tor manuell mit FSA','ZENTRALE,BAUWERK,TUERTOR'),(709,'TUERBRKRA','Brand-/Rauchschutztür/-Tor kraftbetätigt','ZENTRALE,BAUWERK,TUERTOR'),(710,'FENSTERMAN','Fenster (manuell)','ZENTRALE,BAUWERK,FENSTER'),(711,'FENSTERKRA','Fenster / Öffnungen (kraftbetätigte)','ZENTRALE,BAUWERK,FENSTER'),(712,'SONNE','Sonnenschutzanlage','ZENTRALE,BAUWERK,SONNENSCH'),(713,'STEIGLEI','Steigleiter, ortsfest','ZENTRALE,BAUWERK,LEITER'),(714,'ELEKSCHLIESS','elektronische Schließzylinder','ZENTRALE,BAUWERK,SCHLIESS'),(715,'SCHLUESSEL','Schlüsseltresore','ZENTRALE,BAUWERK,SCHLIESS'),(716,'ANSCHLAGEIN','Anschlageinrichtungen','ZENTRALE,BAUWERK,ANSCHLAG'),(717,'UMWEHR','Umwehrungen','ZENTRALE,BAUWERK,UMWEHRUNG'),(718,'DACH1','Dach','ZENTRALE,BAUWERK,DACH'),(719,'HEBE','Hebeanlage','ZENTRALE,AWGANL,ABWASSER'),(720,'ABSCHEID','Abscheider','ZENTRALE,AWGANL,ABWASSER'),(721,'NEUTRALI','Neutralisierungsanlagen','ZENTRALE,AWGANL,ABWASSER'),(722,'KLAER','Kleinkläranlagen','ZENTRALE,AWGANL,ABWASSER'),(724,'TRINKWAVER','Trinkwasserversorgungsanlage','ZENTRALE,AWGANL,WASSER'),(725,'DEZTRINKERW','Dezentrale Trinkwasser-Erwärmungsanlagen','ZENTRALE,AWGANL,WASSER'),(731,'BRUNNEN','Brunnenwasserversorgung','ZENTRALE,AWGANL,WASSER'),(733,'REGENGRAUWA','Regen-/Grauwassernutzungsanlage','ZENTRALE,AWGANL,WASSER'),(734,'GASVERSORG','Gasversorgungsanlage','ZENTRALE,AWGANL,GASANLAGE'),(735,'DESINFEKT','Desinfektionseinrichtungen','ZENTRALE,AWGANL,HYGIENE'),(736,'WASSERKE','Wasserkessel','ZENTRALE,WAERME,WARMEERZ'),(737,'DAMPFKE','Dampf-/Heißwasserkessel','ZENTRALE,WAERME,WARMEERZ'),(738,'WAERMEPU','Wärmepumpe','ZENTRALE,WAERME,WARMEERZ'),(739,'SOLAR','Solaranlage','ZENTRALE,WAERME,WARMEERZ'),(740,'BHKW','Blockheizkraftwerk, wärmegeführt (BHKW)','ZENTRALE,WAERME,WARMEERZ'),(741,'BRENNST','Brennstoffzelle','ZENTRALE,WAERME,WARMEERZ'),(742,'GASTH','Gastherme','ZENTRALE,WAERME,WARMEERZ'),(743,'FERNWAERM','Fernwärme-Übergabestation','ZENTRALE,WAERME,WARMEERZ'),(744,'DOSHEIZ','Dosieranlagen Heizwasser','ZENTRALE,WAERME,HEIZWASSAUF'),(745,'ABGASWAERM','Abgaswärmetauscher','ZENTRALE,WAERME,ABGAS'),(746,'KONDNEUT','Kondensat-Neutralisiationseinrichtung','ZENTRALE,WAERME,ABGAS'),(747,'BRENNSTOFFVER','Brennstoffversorgungsanlage','ZENTRALE,WAERME,BRENNSTOFFV'),(748,'DRUCKHAL','Druckhalteanlage','ZENTRALE,WAERME,WAERMEVERT'),(749,'ENTGASUNG','Entgasungsanlage','ZENTRALE,WAERME,WAERMEVERT'),(750,'WARMEVERTEIL','Wärmeverteilnetz','ZENTRALE,WAERME,WAERMEVERT'),(751,'AUSDEHN','Membran-Ausdehnungsgefäß','ZENTRALE,WAERME,WAERMEVERT'),(752,'STRAHLHEIZ','Gasbefeuerte Strahlungsheizung','ZENTRALE,WAERME,WAERMEVERT'),(753,'UMLHEIZ','Umluftheizer','ZENTRALE,WAERME,WAERMEVERT'),(754,'TRINKWAWAERM','Trinkwassererwärmungsanlage, zentral','ZENTRALE,WAERME,TRINKWASSERW'),(755,'MSRHEIZ','MSR-Technik Heizung','ZENTRALE,WAERME,MSRWAERME'),(756,'ABLUFT','Abluftanlage','ZENTRALE,LUFTTECHN,LTKANLAGE'),(757,'DIGESTOR','Digestorienabluft','ZENTRALE,LUFTTECHN,LTKANLAGE'),(758,'ABSAUG','Absauganlage','ZENTRALE,LUFTTECHN,LTKANLAGE'),(759,'ZULUFT','Zuluftanlage','ZENTRALE,LUFTTECHN,LTKANLAGE'),(760,'ZUABLUFT','Zu- und Abluftanlage (Kombianlage)','ZENTRALE,LUFTTECHN,LTKANLAGE'),(761,'UMLUFT','Umluftanlage','ZENTRALE,LUFTTECHN,LTKANLAGE'),(762,'KOMPKLIMA','Kompaktklimaschrank','ZENTRALE,LUFTTECHN,LTKANLAGE'),(763,'LUFTSCHL','Luftschleieranlage','ZENTRALE,LUFTTECHN,LTKANLAGE'),(764,'MRWA','Maschinelle Rauch-/ und Wärmeabzugsanlage','ZENTRALE,LUFTTECHN,MRA'),(765,'RSDA','Rauchschutz-Druckanlage (DRA)','ZENTRALE,LUFTTECHN,DRA'),(766,'KSA','Klima-Split-Anlage','ZENTRALE,LUFTTECHN,SPLITKLIMA'),(767,'MULTISPL','Multi-Splitanlage Außeneinheit','ZENTRALE,LUFTTECHN,SPLITKLIMA'),(768,'KAELTEERZ','Kälteerzeugungsanlage','ZENTRALE,LUFTTECHN,KAELTE'),(769,'KAELTEV','Kälteverteiler','ZENTRALE,LUFTTECHN,KAELTEVERT'),(770,'DRUCKH','Druckhalteanlage','ZENTRALE,LUFTTECHN,KAELTEVERT'),(771,'ENTGASUNGK','Entgasungsanlage','ZENTRALE,LUFTTECHN,KAELTEVERT'),(772,'AUSDEHNK','Membran-Ausdehnungsgefäß','ZENTRALE,LUFTTECHN,KAELTEVERT'),(773,'DAMPFERZ','Dampferzeuger','ZENTRALE,LUFTTECHN,DAMPF'),(774,'MSRLUEFT','MSR-Technik Lüftung','ZENTRALE,LUFTTECHN,MSRLUFT'),(775,'DRUCKL','Druckluftversorgung','ZENTRALE,LUFTTECHN,MSRLUFT'),(776,'SCHALTHMSP','Schaltanlage Hoch- und Mittelspannung','ZENTRALE,ELEKTR,MITTELSP'),(777,'TRAFO','Transformatorenstation','ZENTRALE,ELEKTR,MITTELSP'),(778,'NEA','Netzersatzanlage (NEA)','ZENTRALE,ELEKTR,SICHSTROM'),(779,'ZBATT','Zentrale Batterie- / Akkumulatorenanlage / USV','ZENTRALE,ELEKTR,SICHSTROM'),(780,'SCHWUNGM','Schwungmassenanlage','ZENTRALE,ELEKTR,SICHSTROM'),(781,'PVA','Photovoltaikanlage','ZENTRALE,ELEKTR,EIGENSTROM'),(782,'SESVA','Sonstige Eigenstromversorgungsanlage','ZENTRALE,ELEKTR,EIGENSTROM'),(783,'NSHV','Niederspannungs-Hauptverteiler','ZENTRALE,ELEKTR,NIEDERSP'),(784,'OVELGER','ortsveränderliche elektrische Geräte','ZENTRALE,ELEKTR,NIEDERSP'),(785,'SIBE','Sicherheitsbeleuchtungsanlage','ZENTRALE,ELEKTR,SIBELEUCH'),(786,'BLITZERD','Blitzschutz- und Erdungsanlagen','ZENTRALE,ELEKTR,BLITZSCHUTZ'),(787,'SCHRANKE','Schrankenanlagen','ZENTRALE,ELEKTR,ELSONSTIGE'),(788,'ELSONST','Sonstiges','ZENTRALE,ELEKTR,ELSONSTIGE'),(789,'TELEKOM','Telekommunikationsanlage','ZENTRALE,FERNMEL'),(790,'SPRECHRUF','Sprech-, Ruf- und Signalanlage','ZENTRALE,FERNMEL'),(791,'ZEITERF','Zeiterfassungsanlage','ZENTRALE,FERNMEL'),(792,'SPRACHAL','Sprachalarmierungsanlage (SAA)','ZENTRALE,FERNMEL'),(793,'BRANDMELD','Brandmeldeanlage (BMA)','ZENTRALE,FERNMEL'),(794,'COWARN','CO-Warnanlage','ZENTRALE,FERNMEL'),(795,'GASWARN','Gaswarnanlage','ZENTRALE,FERNMEL'),(796,'EINBRUEBER','Einbruch- und Überfallmeldeanlage','ZENTRALE,FERNMEL'),(797,'VIDEOUEB','Videoüberwachungsanlage','ZENTRALE,FERNMEL'),(798,'ZUTRITT','Zutrittskontrollanlage','ZENTRALE,FERNMEL'),(799,'GEBFUNK','Gebäudefunkanlage (BOS)','ZENTRALE,FERNMEL'),(800,'FERNSONST','sonstiges Fernmelde-/ IT-Anlage','ZENTRALE,FERNMEL'),(801,'PERSLAST','Personen- und Lastenaufzug','ZENTRALE,FOERDER'),(802,'PATERN','Personenumlaufaufzug','ZENTRALE,FOERDER'),(803,'FAHRTREP','Fahr- /Rolltreppe','ZENTRALE,FOERDER'),(804,'FBEFAHR','Fassadenbefahranlage','ZENTRALE,FOERDER'),(805,'GUETERA','Güteraufzug','ZENTRALE,FOERDER'),(806,'STETIGF','Stetigförderer','ZENTRALE,FOERDER'),(807,'KRAN','Krananlage','ZENTRALE,FOERDER'),(808,'TREPPLIFT','Lifter/Behindertenaufzug','ZENTRALE,FOERDER'),(809,'HEBEBUE','Hebebühne','ZENTRALE,FOERDER'),(810,'PARKRAUM','Parkraumsysteme','ZENTRALE,FOERDER'),(811,'GEBAUTO','Gebäudeautomation (480)','ZENTRALE'),(812,'GLT','Gebäudeautomation, GLT, DDC','ZENTRALE,GEBAUTO'),(813,'LUFTSONST','Lufttechnische Anlagen, sonstige','ZENTRALE,LUFTTECHN'),(814,'WASSLOE','Wasserlöschanlage','ZENTRALE,BRANDSCH,FEUERSELBST'),(815,'GASLOE','Gaslöschanlage','ZENTRALE,BRANDSCH,FEUERSELBST'),(816,'SONSLOE','sonstige Löschanlage','ZENTRALE,BRANDSCH,FEUERSELBST'),(817,'WANDHYTR','Wandhydrant trocken','ZENTRALE,BRANDSCH,FEUERNSELBST'),(818,'WANDHYNA','Wandhydrant nass','ZENTRALE,BRANDSCH,FEUERNSELBST'),(819,'WANDHYNATR','Wandhydrant nass/trocken','ZENTRALE,BRANDSCH,FEUERNSELBST'),(820,'LOEWAANL','Löschwasseranlagen (außen)','ZENTRALE,BRANDSCH,FEUERNSELBST'),(821,'TRFEULOE','tragbare Feuerlöscher','ZENTRALE,BRANDSCH,FEUERNSELBST'),(822,'SAUSTRED','Sauerstoffreduktionsanlage','ZENTRALE,BRANDSCH,BRANDVERM'),(823,'NATRAUAB','Natürlicher Rauchabzug (NRWA)','ZENTRALE,BRANDSCH,NRWA'),(825,'WARMESONS','Wärmeversorgungsanlagen, sonstige','ZENTRALE,WAERME'),(826,'OFGKG','ortsfeste Großküchenanlagen/-gerät','ZENTRALE,NUTZSPEZ,KUECHE'),(827,'KATKNK','Kälteanlagen für TK-Anlagen und NK-Anlagen.','ZENTRALE,NUTZSPEZ,KUECHE'),(828,'OVGKG','ortsveränderliche Küchenausstattungen','ZENTRALE,NUTZSPEZ,KUECHE'),(829,'WAESCHREI','Wäscherei- und Reinigungsanlage','ZENTRALE,NUTZSPEZ,WAESCHE'),(830,'DRUCKLU','Druckluftversorgung','ZENTRALE,NUTZSPEZ,MEDIEN'),(831,'GASVERST','Versorgungsanlage für technisches Gas','ZENTRALE,NUTZSPEZ,MEDIEN'),(832,'TANKSTEL','Tankstelle','ZENTRALE,NUTZSPEZ,MEDIEN'),(833,'MEDLAB','Medizin- und Labortechnische Anlagen','ZENTRALE,NUTZSPEZ,MEDIZIN'),(834,'SICHSCHRA','Sicherheitsschrank ( Gefahrstoffschrank )','ZENTRALE,NUTZSPEZ,MEDIZIN'),(835,'DIGEST','Digestorium','ZENTRALE,NUTZSPEZ,MEDIZIN'),(836,'KLETWAND','Kletterwand','ZENTRALE,NUTZSPEZ,SPORT'),(837,'SPORTGER','Sportgerät','ZENTRALE,NUTZSPEZ,SPORT'),(838,'TRENNSPO','Trennvorhang in Sporthalle','ZENTRALE,NUTZSPEZ,SPORT'),(839,'SPIELPLA','Spielplatzgerät','ZENTRALE,NUTZSPEZ,SPORT'),(840,'ROLLREGA','Rollregal, kraftbetätigt','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(841,'MASCHBUE','Maschinentechnische Bühneneinrichtungen','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(842,'SCHUVORH','Schutzvorhang','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(843,'SCHWIMMB','Schwimmbadtechnische Anlagen','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(844,'AKTENVER','Aktenvernichtungsanlage','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(845,'TAGNACHT','Tag- und Nachtbriefkasten','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(846,'NUTZSONS','Sonstige nutzungsspezifische Anlagen','ZENTRALE,NUTZSPEZ,NUTZSONSTIGE'),(847,'FERNANT','Fernseh- und Antennenanlage','ZENTRALE,FERNMEL'),(850,'AUSSENANL','Außenanlagen (510)','ZENTRALE'),(852,'WASSERAUF','Wasseraufbereitung','ZENTRALE,AWGANL,WASSER'),(854,'ALSG','Abflusslose Sammelgrube (410)','ZENTRALE,AWGANL');
/*!40000 ALTER TABLE `gewerke` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch`
--

DROP TABLE IF EXISTS `raumbuch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(30) NOT NULL,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `parent_id` varchar(30) DEFAULT NULL,
  `tabelle` varchar(30) DEFAULT NULL,
  `merkmal_kurz` varchar(30) NOT NULL,
  `wert` varchar(255) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=2147 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch`
--

LOCK TABLES `raumbuch` WRITE;
/*!40000 ALTER TABLE `raumbuch` DISABLE KEYS */;
/*!40000 ALTER TABLE `raumbuch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch_bezeichner`
--

DROP TABLE IF EXISTS `raumbuch_bezeichner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch_bezeichner` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `bezeichner_lang` varchar(255) NOT NULL,
  `pos` int(2) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch_bezeichner`
--

LOCK TABLES `raumbuch_bezeichner` WRITE;
/*!40000 ALTER TABLE `raumbuch_bezeichner` DISABLE KEYS */;
INSERT INTO `raumbuch_bezeichner` (`row`, `bezeichner_kurz`, `bezeichner_lang`, `pos`) VALUES (3,'LIE','Liegenschaft',1),(4,'GEB','Gebäude',2),(5,'ETAGE','Etage',3),(6,'RAUM','Raum',4);
/*!40000 ALTER TABLE `raumbuch_bezeichner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch_index`
--

DROP TABLE IF EXISTS `raumbuch_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch_index` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `tabelle_kurz` varchar(30) NOT NULL,
  `tabelle_lang` varchar(255) NOT NULL,
  `pos` int(11) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch_index`
--

LOCK TABLES `raumbuch_index` WRITE;
/*!40000 ALTER TABLE `raumbuch_index` DISABLE KEYS */;
INSERT INTO `raumbuch_index` (`row`, `tabelle_kurz`, `tabelle_lang`, `pos`) VALUES (1,'merkmale','Merkmale',NULL),(2,'prozesse','Prozesse',NULL);
/*!40000 ALTER TABLE `raumbuch_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch_merkmale`
--

DROP TABLE IF EXISTS `raumbuch_merkmale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch_merkmale` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `merkmal_kurz` varchar(30) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` tinyint(1) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch_merkmale`
--

LOCK TABLES `raumbuch_merkmale` WRITE;
/*!40000 ALTER TABLE `raumbuch_merkmale` DISABLE KEYS */;
/*!40000 ALTER TABLE `raumbuch_merkmale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch_option2attrib`
--

DROP TABLE IF EXISTS `raumbuch_option2attrib`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch_option2attrib` (
  `row` int(13) NOT NULL AUTO_INCREMENT,
  `option` varchar(50) NOT NULL,
  `attrib` varchar(50) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch_option2attrib`
--

LOCK TABLES `raumbuch_option2attrib` WRITE;
/*!40000 ALTER TABLE `raumbuch_option2attrib` DISABLE KEYS */;
/*!40000 ALTER TABLE `raumbuch_option2attrib` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch_options`
--

DROP TABLE IF EXISTS `raumbuch_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch_options` (
  `row` int(13) NOT NULL AUTO_INCREMENT,
  `option` varchar(50) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch_options`
--

LOCK TABLES `raumbuch_options` WRITE;
/*!40000 ALTER TABLE `raumbuch_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `raumbuch_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raumbuch_prozesse`
--

DROP TABLE IF EXISTS `raumbuch_prozesse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raumbuch_prozesse` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `bezeichner_kurz` varchar(30) NOT NULL,
  `merkmal_kurz` varchar(30) NOT NULL,
  `merkmal_lang` varchar(255) NOT NULL,
  `datentyp` varchar(30) NOT NULL,
  `pflichtfeld` tinyint(1) DEFAULT NULL,
  `minimum` int(5) DEFAULT NULL,
  `maximum` int(5) DEFAULT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raumbuch_prozesse`
--

LOCK TABLES `raumbuch_prozesse` WRITE;
/*!40000 ALTER TABLE `raumbuch_prozesse` DISABLE KEYS */;
/*!40000 ALTER TABLE `raumbuch_prozesse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `todos_disabled`
--

DROP TABLE IF EXISTS `todos_disabled`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `todos_disabled` (
  `row` int(11) NOT NULL AUTO_INCREMENT,
  `device` varchar(30) NOT NULL,
  `prefix` varchar(30) NOT NULL,
  `todo` varchar(255) NOT NULL,
  `comment` varchar(512) NOT NULL,
  `user` varchar(255) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY (`row`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todos_disabled`
--

LOCK TABLES `todos_disabled` WRITE;
/*!40000 ALTER TABLE `todos_disabled` DISABLE KEYS */;
/*!40000 ALTER TABLE `todos_disabled` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-22 11:43:20
